import paramiko
import sys
import os
import logging
import pkgutil
from configparser import ConfigParser
from pathlib import Path


# TODO: Make this into a CLASS (a reminder for my future Me)

class ParamikoController:
    def __init__(self, config_file: str) -> None:
        self.config_file = config_file


def config(filename='config.ini', section='ssh'):
    """
    Reads DDBB configuration file and load it
    :param filename: Configuration file
    :param section: Get different sections of the configuration file
    :return: Configuration parameters for the section selected
    """
    # create a parser
    parser = ConfigParser()

    # within package/mymodule1.py, for example
    configfile = pkgutil.get_data(__name__, filename).decode()

    # read config file
    parser.read_string(configfile)

    # get section, default to postgresql
    db = {}
    if parser.has_section(section):
        params = parser.items(section)
        for param in params:
            db[param[0]] = param[1]
    else:
        raise Exception(
            'Section {0} not found in the {1} file'.format(section, filename))

    return db


def connect_and_send(file_path="csv/resultados.csv"):
    """ Conects via SSH with the remote computer to send a file from local to the remote one.

    :param csv: [description], defaults to "csv/resultados.csv"
    :type csv: str, optional
    :param csv_name: [description], defaults to "resultados.csv"
    :type csv_name: str, optional
    """

    # Read connection parameters
    config_ = config(section='ssh')

    # Extracts file name
    file_name = file_path.rsplit('/', 1)[-1]

    # Se instancia la variable con el cliente Paramiko
    logging.info("Instanciate paramiko's client " +
                 sys._getframe(0).f_code.co_name)

    logging.info("CSV name to be sent: " + str(file_name))

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Se establece la conexion
        ssh.connect(config_['server'], username=config_[
            'username'], password=config_['password'])

        sftp = ssh.open_sftp()

        logging.info(
            "Connection to the remote PC established. Proceeding to sent file...")

        # Se cambian los permisos del archivo a mandar.
        # En este caso se le dan todos los permisos
        os.chmod(str(file_path), 0o777)

        sftp.put(str(file_path), config_['ssh_folder'] + str(file_name))

        sftp.close()
        ssh.close()

        logging.info("File sent succesfully!")
    except Exception as e:
        sys.stderr.write("SSH connection error: {0}".format(e))
        logging.error("File not sent...")


def connect_and_execute(ssh_command: str):
    """ It connects to the remote and execute a given script.

    :param ssh_command: Given command to execute in the remote machine
    :type ssh_command: str
    """
    # Instanciate paramiko's client
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # Read connection parameters
    config_ = config(section='ssh')

    try:

        # Establish connection
        ssh.connect(config_['server'], username=config_[
            'username'], password=config_['password'])

        logging.info(
            "Command to be executed in the remote computer: " + ssh_command)
        ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command(
            ssh_command, get_pty=False)

        # Print out the output of the command execution
        for line in iter(ssh_stdout.readline, ""):
            print(line, end="")

        for line in iter(ssh_stderr.readline, ""):
            print("ERROR")
            print(line, end="")

        # ssh.close()
    except Exception as e:
        sys.stderr.write("SSH connection error: {0}".format(e))
        logging.error("Command not executed properly...")

    logging.info("Command executed on remote succesfully")
    logging.debug("Function finalised " + sys._getframe(0).f_code.co_name)


def connect_and_download():
    """[summary]
    """

    # Instanciate paramiko's client
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # Read connection parameters
    config_ = config(section='scraper_config')

    try:
        home = str(Path.home())
        sftp = sftp = ssh.open_sftp()
        sftp.get(config_['path_to_csv'], home)

        sftp.close()

    except Exception as e:
        logging.error(e)


if __name__ == "__main__":
    # Set log's level
    logging.basicConfig()
    logging.getLogger().setLevel(logging.INFO)

    # Retriving configuratio values to establish ssh connection to the remote computer
    config_ = config(section='scraper_config')
    logging.info("Reading connection info...")

    # Connect and send the desired file to the remote computer
    logging.info("Connecting to the Azure VM and sending CSV file...")
    connect_and_send(file_path=config_['path_to_input'])

    command = "source ~/miniconda3/bin/activate selenium-webscraper; conda env list; conda activate selenium-webscraper; cd /home/tomtom/git-repositories/github-maps-analytics-utils/src/utils; python selenium_web_scrapping.py; ls -lart /home/tomtom"
    connect_and_execute(ssh_command=command)

import numpy


class DistanceOnEarth:

    """
    Set of method to calculate the distance between two (LON, LAT) points
    https://www.movable-type.co.uk/scripts/latlong.html
    """

    @staticmethod
    def _deg2rad(deg: float) -> float:
        """
        Convert deg to rad

        :param deg: degrees
        :return: radians
        """

        return deg * (numpy.pi/180.)


    @classmethod
    def get_distance_from_lat_lon_in_km(cls,
                                        lat1: float,
                                        lon1: float,
                                        lat2: float,
                                        lon2: float,
                                        radius: int = 6371) -> float:
        """
        Find the distance between two points on Earth in km

        :param lat1: Initial point latitude
        :param lon1: Initial point longitude
        :param lat2: Final point latitude
        :param lon2: Final point longitude
        :param radius: Radius to use in the formula
        :return: Distance between two points (in km)
        """

        # Radius of the earth in km
        r = radius

        # Convert LAT and LON difference to radians
        dlat = cls._deg2rad(deg=lat2 - lat1)
        dlon = cls._deg2rad(deg=lon2 - lon1)

        # Haversine formula: https://en.wikipedia.org/wiki/Haversine_formula
        a = numpy.sin(dlat / 2) * numpy.sin(dlat / 2) + numpy.cos(cls._deg2rad(deg=lat1)) * numpy.cos(
            cls._deg2rad(deg=lat2)) * numpy.sin(dlon / 2) * numpy.sin(dlon / 2)

        # arctan2 is the angle in the plane (in radians) between the positive x-axis and the ray from (0,0) to the point (x,y)
        c = 2 * numpy.arctan2(numpy.sqrt(a), numpy.sqrt(1 - a))

        # Distance in km
        d = r * c

        return d


    @classmethod
    def get_distance_from_lat_lon_in_m(cls,
                                        lat1: float,
                                        lon1: float,
                                        lat2: float,
                                        lon2: float,
                                        radius: int = 6371) -> float:
        """
        Find the distance between two points on Earth in meters

        :param lat1: Initial point latitude
        :param lon1: Initial point longitude
        :param lat2: Final point latitude
        :param lon2: Final point longitude
        :param radius: Radius to use in the formula
        :return: Distance between two points (in m)
        """
        return cls.get_distance_from_lat_lon_in_km(lat1, lon1, lat2, lon2, radius) * 1000


if __name__ == "__main__":
    distance = DistanceOnEarth()
    print(distance.get_distance_from_lat_lon_in_m(-34.6036844,	-58.3815591, -34.59431734308192, -58.37376618118092))
    print(distance.get_distance_from_lat_lon_in_km(-34.6036844,	-58.3815591, -34.59431734308192, -58.37376618118092))
    print(distance.get_distance_from_lat_lon_in_m(-34.6036844,	-58.3815591, -34.59431734308192, -58.37376618118092, 6373))
    print(distance.get_distance_from_lat_lon_in_km(-34.6036844,	-58.3815591, -34.59431734308192, -58.37376618118092, 6373))
    # 1262

    print(distance.get_distance_from_lat_lon_in_m(-34.6081059, -58.3509217, -34.58315545192653, -58.398848133446016))
    print(distance.get_distance_from_lat_lon_in_km(-34.6081059, -58.3509217, -34.58315545192653, -58.398848133446016))
    print(distance.get_distance_from_lat_lon_in_m(-34.6081059, -58.3509217, -34.58315545192653, -58.398848133446016, 6373))
    print(distance.get_distance_from_lat_lon_in_km(-34.6081059, -58.3509217, -34.58315545192653, -58.398848133446016, 6373))
    # 5192

    print(distance.get_distance_from_lat_lon_in_m(-36.861974, -57.88212389999999, -34.57577278960212, -58.52386806290648))
    print(distance.get_distance_from_lat_lon_in_km(-36.861974, -57.88212389999999, -34.57577278960212, -58.52386806290648))
    print(distance.get_distance_from_lat_lon_in_m(-36.861974, -57.88212389999999, -34.57577278960212, -58.52386806290648, 6373))
    print(distance.get_distance_from_lat_lon_in_km(-36.861974, -57.88212389999999, -34.57577278960212, -58.52386806290648, 6373))
    # 260811

    print(distance.get_distance_from_lat_lon_in_m(-34.4948079,	-58.5164546, -34.49709336011637, -58.514868451438794))
    print(distance.get_distance_from_lat_lon_in_km(-34.4948079,	-58.5164546, -34.49709336011637, -58.514868451438794))
    print(distance.get_distance_from_lat_lon_in_m(-34.4948079,	-58.5164546, -34.49709336011637, -58.514868451438794, 6373))
    print(distance.get_distance_from_lat_lon_in_km(-34.4948079,	-58.5164546, -34.49709336011637, -58.514868451438794, 6373))
    # 292
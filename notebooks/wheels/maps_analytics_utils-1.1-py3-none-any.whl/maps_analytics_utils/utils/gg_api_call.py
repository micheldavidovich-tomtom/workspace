import googlemaps
import json
import requests
import pandas as pd
import numpy as np
import psycopg2
from configparser import ConfigParser
import geopandas as gpd
import sqlalchemy as db
from sqlalchemy import create_engine
import urllib.parse
import pkgutil
from datetime import datetime


class ApiCalls:
    """ Class """

    def __init__(self):
        pass

# ToDo: CONVERTIR ESTO EN UNA CLASE DONDE LOS MÉTODOS DE LA MISMA, HAGAN LAS DIFERENTES LLAMADAS A LAS DIFERENTES APIs
def config(filename='database_poi.ini', section='postgres_poi'):
    """
    Reads DDBB configuration file and load it
    :param filename: Configuration file
    :param section: Get different sections of the configuration file
    :return: Configuration parameters from the DDBB
    """
    # create a parser
    parser = ConfigParser()

    # within package/mymodule1.py, for example
    configfile = pkgutil.get_data(__name__, filename).decode()

    # read config file
    parser.read_string(configfile)

    # get section, default to postgresql
    db = {}
    if parser.has_section(section):
        params = parser.items(section)
        for param in params:
            db[param[0]] = param[1]
    else:
        raise Exception('Section {0} not found in the {1} file'.format(section, filename))

    return db


def connect():
    """
    Connect to the PostgreSQL database server
    :return: cursor
    """
    try:
        # read connection parameters
        params = config()

        # connect to the PostgreSQL server
        print('Connecting to the PostgreSQL database...')
        conn = psycopg2.connect(**params)

        # create a cursor
        cur = conn.cursor()
        print("Cursor opened")

        # execute a statement
        print('PostgreSQL database version:')
        cur.execute('SELECT version()')

        # display the PostgreSQL database server version
        db_version = cur.fetchone()
        print(db_version)

        return cur

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)


def cursorToDF(cursor, query):
    cursor.execute(query)
    datos = cursor.fetchall()
    names = [x[0] for x in cursor.description]

    if cursor is not None:
        cursor.close()
        print('Cursor closed.')

    return pd.DataFrame(datos, columns=names)


def postgisDDBB(query):
    # Create a database connection
    engine = db.create_engine(
        'postgresql+psycopg2://dba_admin:dba_admin@poi_db_dev.maps-data-analytics-dev.amiefarm.com:5432/poi')
    con = engine.connect_to_postgreSQL()

    # Read PostGIS database with Geopandas.
    data = gpd.read_postgis(sql=query, con=con)

    return data


def callGGApi(row, radius):
    """
    Call to Google's API
    :param row: Row data from Facebook Sample (PostgreSQL DDBB)
    :param radius: Radius of the search circle
    :return: Dataframe with the data retreived from Google
    """
    poi_name = row['name']
    # category = row['category']
    latitude = row['latitude']
    longitude = row['longitude']

    # Google's API key
    gmaps = googlemaps.Client(key='AIzaSyBIfEtTd1A-qnM0D0VUIalclev648OkORk')  # ToDo: put this into de apiKeys.ini file

    # Calling the API from Google and returned in a dict
    places = gmaps.places(query=poi_name, location=(latitude, longitude), radius=radius)

    # Convert results to DataFrame
    df_gg_results = pd.DataFrame(places['results'])

    return df_gg_results

def callTTApi(row, radius):
    """
    Call to TomTom's API
    :param row: Row data from Facebook Sample (PostgreSQL DDBB)
    :param radius: Radius of the search circle
    :return: Dataframe with the data retreived from Google
    """
    poi_name = row['name']
    latitude = row['latitude']
    longitude = row['longitude']

    # URL to the tomtom api ToDo: different API calls depending on the desired request
    apiURLbyCat = "https://api.tomtom.com/search/2/categorySearch"
    apiURLbyName = "https://api.tomtom.com/search/2/poiSearch"

    # apiKey ToDo: put this into de apiKeys.ini file
    apiKey = "VBkzlNlIimgmQJFmbmOrxqFrROAFwjrH"

    # URL encoder
    requestName = urllib.parse.quote_plus(bytes(poi_name))

    # Building TomTom URL
    tomtomURL = "%s/%s.json?lat=%s&lon=%s&radius=%s&key=%s" % (apiURLbyName,
                                                               requestName,
                                                               latitude,
                                                               longitude,
                                                               radius,
                                                               apiKey)
    # Request data from TomTom API
    response = requests.get(tomtomURL)
    print(response.status_code)

    # Convert response to dictionary
    jsonTomTomString = json.loads(response.text)
    results = jsonTomTomString['results']

    # Convert dictionary (response) to DataFrame
    df_tt_results = pd.DataFrame(results)

    return df_tt_results

def callTTApiFromSearch(row, radius):
    """
    Call to TomTom's API
    :param row: Row data from Facebook Sample (PostgreSQL DDBB)
    :param radius: Radius of the search circle
    :return: Dataframe with the data retreived from Google
    """
    poi_name = row['go_name']
    longitude_latitude = row['go_location']

    # Extract latitude and longitude from string and save into an array/list
    longitude_latitude_trans = longitude_latitude.replace('POINT (', '')
    longitude_latitude_trans = longitude_latitude_trans.replace(')', '')
    longitude_latitude_trans = longitude_latitude_trans.split()
    latitude = longitude_latitude_trans[1]
    longitude = longitude_latitude_trans[0]

    # URL to the tomtom api
    apiURLbyCat = "https://api.tomtom.com/search/2/categorySearch"
    apiURLbyName = "https://api.tomtom.com/search/2/poiSearch"
    apiURLbySearchRequest = "https://api.tomtom.com/search/2"

    # Get search request string from csv
    searchRequest = row['search_request_string']

    # apiKey ToDo: put this into de apiKeys.ini file
    apiKey = "VBkzlNlIimgmQJFmbmOrxqFrROAFwjrH"

    tomtomGetRequest = "%s/%s&key=%s" % (apiURLbySearchRequest, searchRequest, apiKey)

    # URL encoder
    # requestName = urllib.parse.quote_plus(bytes(poi_name))

    # Building TomTom URL
    # tomtomURL = "%s/%s.json?lat=%s&lon=%s&radius=%s&key=%s" % (apiURLbyName,
    #                                                            requestName,
    #                                                            latitude,
    #                                                            longitude,
    #                                                            radius,
    #                                                            apiKey)
    # Request data from TomTom API
    response = requests.get(tomtomGetRequest)
    print(response.status_code)

    # Convert response to dictionary
    jsonTomTomString = json.loads(response.text)
    results = jsonTomTomString['results']

    # Convert dictionary (response) to DataFrame
    df_tt_results = pd.DataFrame(results)

    return df_tt_results


def callFBApi(name):
    # ToDo: the idea here is to call de facebook API to retrieve Points of Interest depending on name given as well as location

    pass


def populate_results_table(row, api_response, df_results, provider_id):
    # Check and get the data that's comming with the POIs
    api_response_columns = api_response.columns

    # datetime variable containing current date and time
    now = datetime.now()

    # Google API response data
    if provider_id is 'gg':
        data_to_append = {
            'newcontent_id': row['newcontent_id'],
            'provider_id': provider_id,
            'poi_id': api_response['place_id'],
            'internal_id': '0',  # Zero value for non-TomTom POIs
            'retrieval_date': now,
            'name': api_response['name'],
            'telephone_numbers': api_response[''],
            # 'category_id': api_response['types'][0],
            # 'subcategory': api_response['types'][-1],
            'websites': {api_response['url']} if 'url' not in api_response_columns else {},
            'address': api_response['formatted_address'] if 'formatted_address' not in api_response_columns else np.nan,
            'location': "POINT(%s %s)" % (api_response['geometry']['lat'], api_response['geometry']['lng']),
            # Format to World Geodetic System WGS 84
            'entrypoint_location': "MULTIPOINT((%s %s))" % (
                api_response['geometry']['lat'],
                api_response['geometry']['lng']
            ),
            'business_status': api_response['business_status'],
            'avg_rating_score': api_response['rating'] if 'rating' not in api_response_columns else 0.0,
            'rating_count': api_response['user_rating_total'] if 'user_rating_total' not in api_response_columns else 0,
            'search_rank': api_response[''],  # ToDo: How's this field populated by google? @Wendy
            'search_request_string': 'url_from_Google'  # ToDo: Retrieve URL from Google's request to its API

        }

        df_results_gg_tt = df_results.append(data_to_append)

    elif provider_id is 'tt':
        # ToDo: TomTom retrieval

        data_to_append_tt = pd.DataFrame(
            columns=[
                'poi_name',
                'category',
                'lat',
                'lon',
                'distance',
                'info',
                'provider_id'
            ]
        )

        # Retrieve sub-fields from different columns
        data_to_append_tt['poi_name'] = api_response['poi'].apply(lambda x: x.get('name'))
        data_to_append_tt['category'] = api_response['poi'].apply(lambda x: x.get('categorySet'))
        data_to_append_tt['lat'] = api_response['position'].apply(lambda x: x.get('lat'))
        data_to_append_tt['lon'] = api_response['position'].apply(lambda x: x.get('lon'))
        data_to_append_tt['info'] = api_response['info']
        data_to_append_tt['distance'] = api_response['dist']
        data_to_append_tt['provider_id'] = provider_id

        # Second part of the retrieval from sub-fields in different columns
        data_to_append_tt['category'] = data_to_append_tt['category'].apply(lambda x: x[0].get('id'))  # Pointing to 0 position since categorySet is a List of 1 element only (were it has the category)

        # Some transformation
        data_to_append_tt['category'] = data_to_append_tt['category'].astype(str)
        # ToDo: Need to be removed the last digits of the value
        # data_to_append_tt['category'] = data_to_append_tt['category'].map(
        #     lambda x: str(x)[:-3] if x.str.len() > 4 else x
        # )

        # Adding current time to track it
        data_to_append_tt['date_timestamp'] = now

        # data_to_append_tt['category'] = data_to_append_tt.apply(
        #     lambda x: x['category'] // 1000 if (x['category'].astype(str).str.count('\d') > 4) else x['category']
        # )

        # Remove prefix from 'info' field
        # longitude_latitude_trans = longitude_latitude.replace('POINT (', '')
        # longitude_latitude_trans = longitude_latitude_trans.replace(')', '')
        # longitude_latitude_trans = longitude_latitude_trans.split()
        # latitude = longitude_latitude_trans[1]
        # longitude = longitude_latitude_trans[0]

    df_results_gg_tt = df_results.append(data_to_append_tt)

    return df_results_gg_tt

def writeToPostgreSQL(df):
    engine = create_engine('postgresql://dba_admin:dba_admin@poi_db_dev.maps-data-analytics-dev.amiefarm.com:5432/poi')


    df.to_sql('api_calls_tt_results', engine, if_exists='append', method='multi', schema='analysis', index=False)


if __name__ == '__main__':
    # Search radius setter
    radius = "200"

    # Connect to PostgreSQL DDBB and return cursor to operate with it
    cursor = connect()
    print(cursor)

    gg_name = "le gite des badons"
    gg_longitude = "5.5527736"
    gg_latitude = "44.9090394"

    row = pd.DataFrame()

    row['name'] = gg_name
    row['latitude'] = gg_latitude
    row['longitude'] = gg_longitude

    # df_facebook_data = cursorToDF(cursor, query)

    # Read samples from CSV
    df_csv = pd.read_csv("../../data/external/pssr_intake_send_to_api.csv")

    # Retrieve data from PostgreSQL DDBB (Facebook data)
    # query = "select * from newcontent.newcontent_sample ns"
    # postgis_data = postgis_ddbb(query)

    # Set results DataFrame:
    df_results_gg_tt = pd.DataFrame(columns=[
        'newcontent_id',
        'provider_id',
        'response_id',
        'poi_id',
        'internal_id',
        'retrieval_date',
        'name',
        'telephone_numbers',
        'category_id',
        'subcategory_id',
        'websites',
        'address',
        'location',
        'entrypoint_location',
        'business_status',
        'avg_rating_score',
        'rating_count',
        'search_rank',
        'search_request_string'
    ])

    # TomTom final results initialization dataframe
    df_results_tt = pd.DataFrame()

    for index, row in df_csv.iterrows():
        # print("Searching for %s" % row['name'])
        # longitude_latitude = row['location']



        # Calling Google's API
        # gg_places = call_gg_api(longitude_latitude_trans[0], longitude_latitude_trans[1], category_name)
        try:
            gg_places = callGGApi(row, radius)

            # Control that data is not empty
            if gg_places.empty == True:
                # ToDo: Collect all empty POIs to another table
                raise Exception("Empty DataFrame")
            else:
                print("Google found: %s" % gg_places['name'])

                # Set provider ID
                provider_id = 'gg'

                # Populate results table
                # df_results_gg_tt = populate_results_table(row, gg_places, df_results_gg_tt, provider_id_gg, now)


        except Exception as e:
            print("No Google response for %s" % row['name'])

        # Callint TomTom's API
        # tt_places = call_tt_api(longitude_latitude_trans[0], longitude_latitude_trans[1], tt_category_id)
        try:
            tt_places = callTTApiFromSearch(row, radius)

            # Control that data is not empty
            if tt_places.empty == True:
                # ToDo: Collect all empty POIs to another table
                raise Exception("Empty DataFrame")
            else:
                print("TomTom found: %s" % tt_places['poi'])

                # Set provider ID
                provider_id = 'tt'

                # Populate results table
                df_results_tt = populate_results_table(row=row, api_response=tt_places, df_results=df_results_tt,
                                                       provider_id=provider_id)



        except Exception as e:
            print("No TomTom response for %s" % row['go_name'])

        # df_results_gg_tt = pd.DataFrame({
        #     'newcontent_id': pd.Series([], dtype='str'),
        #     'provider_id': pd.Series([], dtype='str'),
        #     'response_id': pd.Series([], dtype='str'),
        #     'poi_id': pd.Series([], dtype='str'),
        #     'internal_id': pd.Series([], dtype='int'),
        #     'retrieval_date': pd.Series([], dtype='object'),
        #     'name': pd.Series([], dtype='str'),
        #     'telephone_numbers': pd.Series([], dtype='object'),
        #     'category_id': pd.Series([], dtype='str'),
        #     'subcategory_id': pd.Series([], dtype='str'),
        #     'websites': pd.Series([], dtype='str'),
        #     'address': pd.Series([], dtype='str'),
        #     'location': pd.Series([], dtype='object'),
        #     'entrypoint_location': pd.Series([], dtype='object'),
        #     'business_status': pd.Series([], dtype='str'),
        #     'avg_rating_score': pd.Series([], dtype='float'),
        #     'rating_count': pd.Series([], dtype='int'),
        #     'search_rank': pd.Series([], dtype='int'),
        #     'search_request_string': pd.Series([], dtype='str')
        # })

    # Write to the postgreSQL DDBB
    writeToPostgreSQL(df=df_results_tt)

    print("FINISHED!")

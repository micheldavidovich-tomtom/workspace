from shapely import geometry
import numpy as np
from trimesh.path.polygons import sample as polygon_sample
from trimesh.points import remove_close as remove_close_points
import logging


def sample_surface_even(
    polygon: geometry.Polygon, count: int, radius: float = None, safe_factor: int = 3
):
    """Sample surface even
    * AAF: adapted from https://github.com/mikedh/trimesh/blob/main/trimesh/sample.py
    to work with shapely poilygons.

    Sample the interior of a polygon, returning samples which are
    VERY approximately evenly spaced. This is accomplished by
    sampling and then rejecting pairs that are too close together.
    Note that since it is using rejection sampling it may return
    fewer points than requested (i.e. n < count). If this is the
    case a log.warning will be emitted.

    :param polygon: Geometry to sample the surface of
    :type polygon: geometry.Polygon
    :param count: Number of points to return
    :type count: int
    :param radius: Removes samples below this radius, defaults to None
    :type radius: float, optional
    :param safe_factor: Create enough points to discard later, defaults to 3
    :type safe_factor: int, optional

    Returns:
        list[Points]: Points in space on the surface of mesh

    Example:
        Using pandas to extract list of Points from column with polygon or multipolygon (shapely)
        $ df['points'] = df['geom'].apply(lambda polygon: sample_surface_even(polygon, 100, 0.05)
    """
    # guess radius from area
    if radius is None:
        radius = np.sqrt(polygon.area / (safe_factor * count))

    # get points on the surface
    points = polygon_sample(polygon, count * safe_factor)

    # remove the points closer than radius
    points, mask = remove_close_points(points, radius)

    points = [geometry.Point(point) for point in points]
    # we got all the samples we expect
    if len(points) >= count:
        return points[:count]

    # warn if we didn't get all the samples we expect
    logging.warning("only got {}/{} samples!".format(len(points), count))

    return points


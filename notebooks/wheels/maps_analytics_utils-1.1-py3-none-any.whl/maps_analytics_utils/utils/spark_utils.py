from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col
from pyspark.dbutils import DBUtils
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.streaming import DStream
from functools import reduce 


def unionAll(*dfs:SparkDataFrame) -> SparkDataFrame:
    """Useful function to concat N pyspark dataframes at once.

    :return: Concatenated PySaprk dataframe.
    :rtype: pyspark.sql.DataFrame
    """
    return reduce(SparkDataFrame.unionAll, dfs)


def get_dbutils(spark: SparkSession) -> DBUtils:
    """Function that returns (databricks) dbutils class from pyspark.

    :param spark: Input pyspark SparkSession class.
    :type spark: pyspark.sql.SparkSession
    :return: DBUtils class from pyspark.
    :rtype: pyspark.dbutils.DBUtils
    """
    if not spark:
        spark = SparkSession.builder.getOrCreate()
    #from pyspark.dbutils import DBUtils
    return DBUtils(spark)


def cast_all_columns_to_string_type(input_df: DataFrame) -> DataFrame:
    """PySpark function which converts all column type of pyspark dataframe to string.

    :param input_df: Input pyspark dataframe.
    :type input_df: pyspark.sql.DataFrame
    :return: Dataframe all column type of pyspark dataframe to string.
    :rtype: pyspark.sql.DataFrame
    """
    output_df = input_df.select([col(c).cast("string") for c in input_df.columns])
    return output_df


def read_spark_dataframe(path: str, table_format: str) -> SparkDataFrame:
    """Function to read a table in Azure Datalake Gen2 and returns it in Spark Dataframe format.

    :param path: Path of the folder/table in datalake to be read.
    :type path: str
    :param format: Format of the files in the folder to be read.
    :type format: str
    :return: Spark dataframe with the data of the table read.
    :rtype: SparkDataFrame
    """

    sdf = (spark.readStream
        .format(table_format)
        .option("path", path)
        .load())

    return sdf


def readStream_spark_dataframe(path: str, table_format: str) -> DStream:
    """Function that loads a dataset from external storage given a path to it.

    :param path: Path of the file in the folder/table in the datalake to be read.
    :type path: str
    :param table_format: Format of the files in the folder to be read.
    :type table_format: str
    :return: Spark stream dataframe with the data of the table read.
    :rtype: SparkDataFrame
    """

    # Read new step for next iteration
    ssdf = (spark
        .readStream
        .format(table_format)
        .option("path", path)
        .load())

    return ssdf


def generate_id(input_sdf: SparkDataFrame, id_column_name: str, results_sdf: SparkDataFrame) -> SparkDataFrame:
  """
  TODO
  """
  
  # First time run
  if results_sdf is None:
    print("Origins of the table...")
    # It creates the first ID if it was never created before
    response = (input_sdf
           .withColumn(id_column_name, lit(datetime.now().strftime('%Y%m%d') + "-000"))
          )
    
  else:
    
    # If is not the first time to be executed then find the last ID executed so it can add next ID to the iteration
    if results_sdf.filter(col("matching_results_id").isNotNull()):
      print("Not the first time executed.")
      # Split ID into the date part and the ID part
      split_col = split(results_sdf[id_column_name], '-')
            
      splitted_df = (results_sdf
                     .withColumn('date', split_col.getItem(0))
                     .withColumn('id', split_col.getItem(1))
                    )
            
      # Check if date is today
      checked_splitted_df = splitted_df.where(col("date").isin({datetime.now().strftime('%Y%m%d')}))

      # and if there are already executions for today, it have it into account for the next iteration ID
      if checked_splitted_df.count() > 0:
        print("Not the first execution of today.")
        checked_splitted_df = checked_splitted_df.withColumn("id", checked_splitted_df["id"].cast(IntegerType()))

        # It collects the maximum id (maximum iteration so far of executions)
        max_id = checked_splitted_df.agg({"id": "max"}).collect()[0][0]

        # Creates new value for the ID column in the new results dataframe
        response = (input_sdf
                    .withColumn(id_column_name, lit(datetime.now().strftime('%Y%m%d') + "-" + format(max_id + 1, "03")))
                   )

      else:
        print("First execution of the day...")
        # It creates the first ID if it was never created before
        response = (input_sdf
                    .withColumn(id_column_name, lit(datetime.now().strftime('%Y%m%d') + "-000"))
                   )

    else:
      print("First execution ever...")
      # It creates the first ID if it was never created before
      response = (input_sdf
             .withColumn(id_column_name, lit(datetime.now().strftime('%Y%m%d') + "-000"))
            )
    
  return response


def truncate(n: float, decimals: int=0) -> int:
    """
    Simple function which truncates an incoming float value (n) and returns its integer value
    based on its multiplier value, later divided by the same multiplier value.
    :param n: Input numerical value.
    :type n: float
    :param decimals: Input integer which defines the number of decimal point to return. Defaults to 0. 
    :type decimals: int
    :rparam result: Output integer value after the truncate process of the input value (n).
    :rtype result: int
    """

    multiplier = 10 ** decimals
    result = int(n * multiplier) / multiplier

    return result


def distance(row: list) -> float:
    """
    Function which calculates the distance in meters between two XY coodinates. The function requires
    the latitude and longitude for each point. At the end of the function, we truncate the output distance
    value with a maximun of 4 decimal points.
    :param row: Latitude value of first coordinate point.
    :type row: array.
    :rparam distance: Distance between point in meters.
    :rtype distance: float
    """

    lt1 = float(row[0])
    ln1 = float(row[1])
    lt2 = float(row[2])
    ln2 = float(row[3])

    print(lt1)
    print(ln1)

    print(lt2)
    print(ln2)

    R = 6373.0 # approximate radius of earth in km

    lat1 = radians(lt1) # gg_point
    lon1 = radians(ln1)

    lat2 = radians(lt2) # provider_point
    lon2 = radians(ln2)

    dlon = lon2 - lon1
    dlat = lat2 - lat1

    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = truncate(R * c, 4) * 1000

    return distance


def calculate_distance(input_sdf: SparkDataFrame) -> SparkDataFrame:
    """Function that calculates the distance in meters between the reference POI and the 
    provider POI associated to the reference POI.

    :param input_sdf: Input Spark Dataframe where reference POI and provider POI data is.
    :type input_sdf: SparkDataFrame
    :return: Spark Dataframe with both reference and provider POI data and an extra column with
    the distance in meters between them.
    :rtype: SparkDataFrame
    """

    # Define UDF for calculating the distance between POIs for each row.
    distance_udf = udf(lambda x: distance(x), FloatType())

    # Calculating distance... (applying UDF)
    output_sdf = input_sdf.withColumn(
        "location_distance_m", 
        distance_udf(array(col("ref_lat"), col("ref_lon"), col("api_lat"), col("api_lon")))
        )

    return output_sdf
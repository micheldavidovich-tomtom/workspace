from pandas.core.construction import array
from selenium import webdriver
#from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from configparser import ConfigParser
from http_request_randomizer.requests.proxy.requestProxy import RequestProxy
import psycopg2
import pandas as pd
import numpy as np
import googlemaps
import logging
import pkgutil
import time
import os
import random
from fake_useragent import UserAgent
from scipy.stats import truncnorm
from distutils.sysconfig import get_python_lib


# PATH = "/usr/local/bin/chromedriver"
MAX_RETRY = 5
# URL to open up each of the POI's google maps site
google_maps_url = "https://www.google.com/maps/place/?q=place_id:"
# you may get different number of proxy when  you run this at each time
# req_proxy = RequestProxy()
# proxies = req_proxy.get_proxy_list()  # this will create proxy list


def config(filename='config.ini', section='postgres_poi'):
    """
    Reads DDBB configuration file and load it
    :param filename: Configuration file
    :param section: Get different sections of the configuration file
    :return: Configuration parameters for the section selected
    """
    # create a parser
    parser = ConfigParser()

    # within package/mymodule1.py, for example
    configfile = pkgutil.get_data(__name__, filename).decode()

    # read config file
    parser.read_string(configfile)

    # get section, default to postgresql
    db = {}
    if parser.has_section(section):
        params = parser.items(section)
        for param in params:
            db[param[0]] = param[1]
    else:
        raise Exception(
            'Section {0} not found in the {1} file'.format(section, filename))

    return db


def connect_to_postgreSQL():
    """
    Connect to the PostgreSQL database server
    :return: cursor
    """
    try:
        # read connection parameters
        params = config()

        # connect to the PostgreSQL server
        print('Connecting to the PostgreSQL database...')
        conn = psycopg2.connect(**params)

        # create a cursor
        cur = conn.cursor()
        print("Cursor opened")

        # execute a statement
        print('PostgreSQL database version:')
        cur.execute('SELECT version()')

        # display the PostgreSQL database server version
        db_version = cur.fetchone()
        print(db_version)

        return cur

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)


def cursorToDF(cursor, query):
    cursor.execute(query)
    datos = cursor.fetchall()
    names = [x[0] for x in cursor.description]

    if cursor is not None:
        cursor.close()
        print('Cursor closed.')

    return pd.DataFrame(datos, columns=names)


class WebDriver:
    location_data = {}
    # Set log's level
    logging.basicConfig()
    logging.getLogger().setLevel(logging.INFO)

    def __init__(self, driver, search_type):
        """
        Initial constructor of the class
        @param driver: driver intances (webdriver from Chrome)
        """
        # self.options = Options()
        # self.options.add_argument("--headless")
        # webdriver.Chrome(PATH, options=self.options)
        self.driver = driver
        self.search_type = search_type
        self.location_data["rating"] = "NA"
        self.location_data["reviews_count"] = "NA"
        self.location_data["location"] = "NA"
        self.location_data["contact"] = "NA"
        self.location_data["website"] = "NA"
        self.location_data["Time"] = {"Monday": "NA", "Tuesday": "NA", "Wednesday": "NA", "Thursday": "NA",
                                      "Friday": "NA", "Saturday": "NA", "Sunday": "NA"}
        self.location_data["Reviews"] = []
        self.location_data["Popular Times"] = {"Monday": [], "Tuesday": [], "Wednesday": [], "Thursday": [],
                                               "Friday": [], "Saturday": [], "Sunday": []}
        self.older_than_a_year = False
        # self.ip_address = proxies[0].get_address()
        # self.ip_country = proxies[0].country

    def get_location_data(self):
        """
        Function that gets information about the POI searched from google maps (Average rating, total reviews, address,
        phone number and website)
        @return: No
        """

        logging.info("Collecting data from the POI...")

        try:
            # ToDo: Fix this (not getting correct average rating)
            avg_rating = self.driver.find_element_by_xpath(
                "//span[contains(@jsaction, 'pane.rating.moreReviews')]")
            # avg_rating = self.driver.find_element_by_xpath("//span[contains(@class, 'section-star-display')]")
            # avg_rating = self.driver.find_element_by_class_name("section-star-display")
            logging.debug("avg rating element found!")

        except Exception as e:
            logging.error(e)
            avg_rating = None

        try:
            total_reviews = self.driver.find_element_by_xpath(
                "//button[contains(@jsaction, 'pane.rating.moreReviews')]")
            logging.debug("total reviews element found!")

        except Exception as e:
            logging.error(e)
            # If not reviews found, set value as 0 so when calculating how many times has to scroll, then would be 0
            # as well --> Amount of scrolls to be done = total_reviews / 10(number of reviews loaded per scroll)
            total_reviews = '0 reviews'

        try:
            address = self.driver.find_element_by_css_selector(
                "[data-item-id='address']")
            logging.debug("address element found!")

        except Exception as e:
            logging.error(e)
            address = None

        try:
            phone_number = self.driver.find_element_by_css_selector(
                "[data-tooltip='Copy phone number']")
            logging.debug("phone number element found!")

        except Exception as e:
            logging.error(e)
            phone_number = None

        try:
            website = self.driver.find_element_by_css_selector(
                "[data-item-id='authority']")
            logging.debug("website element found!")

        except Exception as e:
            logging.error(e)
            website = None

        try:
            self.location_data["rating"] = avg_rating.text if avg_rating is not None else 'None'
            aux_reviews = total_reviews.text.split(' re') if (total_reviews.text is not '') or (
                total_reviews is not None) else '0'
            self.location_data["reviews_count"] = aux_reviews[0]
            self.location_data["location"] = address.text if address is not None else 'None'
            self.location_data["contact"] = phone_number.text if phone_number is not None else 'None'
            self.location_data["website"] = website.text if website is not None else 'None'

        except Exception as e:
            logging.error(e)

    def click_agree_cookies(self):
        try:
            agree = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//input[contains(@class, 'button')]")))
            agree.click()
            logging.debug("Agree cookies Clicked!")

        except Exception as e:
            logging.error(e)
            logging.error(
                "'Accept cookies' button not found. Keep on running...")

    def click_open_close_time(self):
        # ToDo: Review this part and correct it
        if (len(list(self.driver.find_elements_by_class_name("mapsConsumerUiSubviewSectionOpenhours"))) != 0):
            element = self.driver.find_element_by_class_name(
                "cX2WmPgCkHi__section-info-hour-text")
            self.driver.implicitly_wait(5)

            ActionChains(self.driver).move_to_element(
                element).click(element).perform()

    def get_location_open_close_time(self):
        # ToDo: Review this part and correct it
        try:

            # ToDo: Permanently closed 'mapsConsumerUiSubviewSectionOpenhours__section-info-hour-text'

            days = self.driver.find_elements_by_class_name(
                "mapsConsumerUiSubviewSectionOpenhours")  # It will be a list containing all HTML section the days names.
            times = self.driver.find_elements_by_class_name(
                "lo7U087hsMA__row-interval")  # It will be a list with HTML section of open and close time for the respective day.

            # Getting the text(day name) from each HTML day section.
            day = [a.text for a in days]
            open_close_time = [a.text for a in
                               times]  # Getting the text(open and close time) from each HTML open and close time section.

            for i, j in zip(day, open_close_time):
                self.location_data["Time"][i] = j

        except Exception as e:
            logging.error(e)

    def get_popular_times(self):
        # ToDo: Review this part and correct it
        try:
            a = self.driver.find_elements_by_class_name(
                "section-popular-times-graph")  # It will be a List of the HTML Section of each day.
            dic = {0: "Sunday", 1: "Monday", 2: "Tuesday",
                   3: "Wednesday", 4: "Thursday", 5: "Friday", 6: "Saturday"}
            l = {"Sunday": [], "Monday": [], "Tuesday": [], "Wednesday": [], "Thursday": [], "Friday": [],
                 "Saturday": []}
            count = 0

            for i in a:
                b = i.find_elements_by_class_name(
                    "section-popular-times-bar")  # It will be a list of HTML Section of each hour in a day.
                for j in b:
                    x = j.get_attribute(
                        "aria-label")  # It gets the busy percentage value from HTML Section of each hour.
                    l[dic[count]].append(x)
                count = count + 1

            for i, j in l.items():
                self.location_data["Popular Times"][i] = j

        except Exception as e:
            print(e)

    def click_all_reviews_button(self):
        """
        Function that opens up 'All reviews' section from a google maps POI.
        @return: True in case 'All reviews' section is clicked/opened. False, if not.
        """
        try:

            # WebDriverWait(self.driver, 20).until(EC.element_to_be_clickable((By.CLASS_NAME, "allxGeDnJMl__button")))

            element = self.driver.find_element_by_xpath(
                "//button[contains(@jsaction, 'pane.rating.moreReviews')]")
            element.click()
            # Generates random numbers with a normal/gaussian distribution, bounded between 2 and 10, and centered in 7
            pause_time = self.get_random_gauss()

            time.sleep(pause_time)

        except Exception as e:
            logging.error(e)
            logging.info("No 'All reviews' button for this POI")
            self.location_data["reviews_count"] = {}

            return False

        return True

    def sort_reviews_newest(self, hotel_category):
        # Variables to help clicking the 'Sort' button
        clicked = False
        tries = 0

        # Generates random numbers with a normal/gaussian distribution, bounded between 5 and 10, and centered in 7
        pause_time = self.get_random_gauss()

        while not clicked and tries < MAX_RETRY:

            try:
                # Avoiding undesired events due to AJAX calls in google maps website. Waiting until element appears.
                wait = WebDriverWait(self.driver, 10)

                if hotel_category == True:
                    sorting_element = wait.until(EC.presence_of_element_located(
                        (By.XPATH, "//div[contains(@aria-label, 'Most relevant')]")))

                else:
                    sorting_element = wait.until(EC.presence_of_element_located(
                        (By.XPATH, "//button[contains(@data-value, 'Sort')]")))
                # Click on the sort button
                # sorting_element = self.driver.find_element_by_xpath("//button[contains(@data-value, 'Sort')]")
                sorting_element.click()
                time.sleep(pause_time)

                # Waits until DOM element appears
                wait.until(EC.presence_of_element_located(
                    (By.XPATH, "//div//ul[contains(@role, 'menu')]//li[contains(@data-index, '1')]")))

                # Click on the newest to oldest kind of sorting
                element = self.driver.find_element_by_xpath(
                    "//div//ul[contains(@role, 'menu')]//li[contains(@data-index, '1')]")
                element.click()
                time.sleep(pause_time)
                # Get away of the loop once success
                clicked = True

            except Exception as e:
                logging.error(e)
                logging.error("Not able to click the 'Sort' button")
                tries += 1
                return False

        return True

    def scroll_the_page(self):
        """
        Function that scrolls the page where all POI's reviews are.
        @return: No.
        """

        logging.info(
            "Scrolling the reviews to retrieve all of them. Please wait...")

        try:
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, "section-layout")))  # Waits for the page to load.

            # Number of times we will scroll the scroll bar to the bottom.
            # It is divided by 10, because 10 is the number of reviews appearing in each scroll.
            max_count = int(int(self.location_data.get(
                'reviews_count').replace(',', '')) / 10)
            x = 0

            while (x < max_count):

                # Generates random numbers with a normal/gaussian distribution, bounded between 2 and 10, and centered in 7
                pause_time = self.get_random_gauss()

                logging.info("Pause time between reviews scrolling: {pause_time} sec".format(
                    pause_time=pause_time))

                # Before it continues scrolling, check if the review is older than a year. If so, we are not interested in that POI
                try:
                    review_date = self.driver.find_elements_by_xpath(
                        "//div[@data-review-id]//span[contains(@jsan, 'date')]")[-1].text

                    logging.info("Oldest review date so far: {review_date}".format(
                        review_date=review_date))
                except Exception as e:
                    logging.error(e)
                    logging.error("No reviews found")

                word_list = ['year', 'years']
                # Breaks the loop in case the word 'year' appears on the review's date
                if any(word in review_date for word in word_list):
                    # Setting a flag to the older than a year POIs (this flag will mark down each POI which meets this condition)
                    self.older_than_a_year = True

                    logging.info(
                        "POI is older than a year. Stopping the scrolling...")

                    break

                # Waits
                WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "div.section-layout.section-scrollbox")))

                # It gets the section of the scroll bar
                scrollable_div = self.driver.find_element_by_css_selector(
                    "div.section-layout.section-scrollbox")
                # scrollable_div = self.driver.find_element_by_xpath(
                #     "//div[contains(@class, 'section-layout section-scrollbox mapsConsumerUiCommonScrollable__scrollable-y mapsConsumerUiCommonScrollable__scrollable-show')]")

                try:
                    self.driver.execute_script('arguments[0].scrollTop = arguments[0].scrollHeight',
                                               scrollable_div)  # Scroll it to the bottom
                except Exception as e:
                    logging.error(e)

                time.sleep(pause_time)  # wait for more reviews to load
                x = x + 1

                logging.debug("REVIEW NUMBER: {}".format(x))

        except Exception as e:
            logging.error("Scrolling reviews went wrong...")
            logging.error(e)

    def expand_all_reviews(self):
        """
        Function that expands all reviews to get details from each one of them.
        @return: No.
        """

        logging.info(
            "Expanding all reviews to collect data from them. Please wait...")

        try:

            # Generates random numbers with a normal/gaussian distribution, bounded between 2 and 10, and centered in 7
            pause_time = self.get_random_gauss()

            logging.info("Pause time expanding each review: {pause_time} sec".format(
                pause_time=pause_time))

            # Avoiding undesired events due to AJAX calls in google maps website. Waiting until element appears.
            wait = WebDriverWait(self.driver, 10)
            wait.until(EC.presence_of_element_located(
                (By.XPATH, "//button[contains(@jsaction, 'pane.review.expandReview')]")))

            element = self.driver.find_elements_by_xpath(
                "//button[contains(@jsaction, 'pane.review.expandReview')]")
            for i in element:
                i.click()
                time.sleep(pause_time)

            logging.info("Reviews expansion finished.")

        except Exception as e:
            logging.error(e)

    def get_random_gauss(self):
        """[summary]

        :return: [description]
        :rtype: [type]
        """
        gauss_rand = self.get_truncated_normal(mean=5, sd=2, low=2, upp=10)
        pause_time = gauss_rand.rvs()

        return pause_time

    def get_reviews_data(self):
        """
        Function that retrieves all data from all reviews that have been scrolled.
        @return: No
        """
        try:
            logging.info("Retrieving review's data... Please wait...")

            review_names = self.driver.find_elements_by_xpath(
                "//div[@data-review-id]//div[contains(@class, 'title')]")  # Its a list of all the HTML sections with the reviewer name.
            review_text = self.driver.find_elements_by_xpath(
                "//div[@data-review-id]//span[contains(@class, 'text')]")  # Its a list of all the HTML sections with the reviewer reviews.
            review_dates = self.driver.find_elements_by_xpath(
                "//div[@data-review-id]//span[contains(@jsan, 'date')]")  # Its a list of all the HTML sections with the reviewer reviewed date.
            review_stars = self.driver.find_elements_by_xpath(
                "//div[@data-review-id]//span[contains(@aria-label, 'star')]")  # Its a list of all the HTML sections with the reviewer rating.

            review_stars_final = []

            for i in review_stars:
                review_stars_final.append(i.get_attribute("aria-label"))

            review_names_list = [a.text for a in review_names]
            review_text_list = [a.text for a in review_text]
            review_dates_list = [a.text for a in review_dates]
            review_stars_list = [a for a in review_stars_final]

            # Reset previous state of the attribute 'Reviews'
            self.location_data['Reviews'] = []

            for (a, b, c, d) in zip(review_names_list, review_text_list, review_dates_list, review_stars_list):
                self.location_data["Reviews"].append(
                    {"name": a, "review": b, "date": c, "rating": d})

            logging.info("Review's data retrieval finished!")

        except Exception as e:
            logging.error(e)
            logging.error("Not able to get all data from reviews...")

    def scrape(self, url):
        """
        Function that initialise the spider that scrap google maps website.
        @param url: Search's URL for google maps.
        @return: Returns the scraped data from google maps website.
        """

        logging.info(
            "Starting to scrape POIs from google maps. Please wait...")

        try:
            # Get is a method that will tell the driver to open at that particular URL
            self.driver.get(url)
            # logging.debug("Driver URL element")
            # logging.debug(driver.page_source)
            # logging.info("IP: {}".format(self.ip_address))
            # logging.info("Country: {}".format(self.ip_country))

        except Exception as e:
            logging.error(e)
            return

        self.click_agree_cookies()
        time.sleep(3)  # Waiting for the page to load.

        # self.click_open_close_time()  # ToDo: Fix it. Calling the function to click the open and close time button.
        # Calling the function to get all the location data.
        self.get_location_data()
        # self.get_location_open_close_time()  # Calling to get open and close time for each day.
        # self.get_popular_times()  # Gets the busy percentage for each hour of each day.

        # Clicking the all reviews button and redirecting the driver to the all reviews page.
        if self.click_all_reviews_button() == False:
            return (self.location_data)

        # Find the sorting button depending on if the category is hotel or not (this sorting button changes if it is hotels category)
        if 'hotel' in self.search_type:
            # Sorting all reviews from newest to oldest
            self.sort_reviews_newest(hotel_category=True)

        else:
            # Sorting all reviews from newest to oldest
            self.sort_reviews_newest(hotel_category=False)

        self.scroll_the_page()  # Scrolling the page to load all reviews.

        logging.info("Scrolling all reviews has finished.")

        # Expanding the long reviews by clicking see more button in each review.
        self.expand_all_reviews()
        self.get_reviews_data()  # Getting all the reviews data.

        logging.info("Scraping process finished.")

        return (self.location_data)  # Returning the Scraped Data.

    def get_circle_from_postgreSQL(self, cursor, category):

        logging.info("Requesting circle from PostgeSQL DDBB...")
        try:
            query = """
             select *
                from data.reference_pois rp
            where rp.country = 'esp'
            and rp.address ilike ('%Madrid%')
            and rp.quality = 'q1'
            and rp.search_group <> 'Top50Brands'
            and (rp.classification[1].category_id ilike ('%{}%')
            or rp.classification[1].subcategory_id ilike('%{}%'))
            """.format(category, category)

            df_circle = cursorToDF(cursor, query)

            # So far getting first sample_id (circle)
            sample_id = df_circle.iloc[0]['sample_id']

        except Exception as e:
            logging.error(e)
            sample_id = None

        return sample_id

    def get_pois_from_circle(self, cursor, sample_id):

        try:
            query = """
            select *
                from data.reference_pois rp
                where rp.country = 'esp'
                and rp.address ilike ('%Madrid%')
                and rp.sample_id = '{}'
                """.format(sample_id)

            df_pois_circle = cursorToDF(cursor, query)

        except Exception as e:
            print(e)
            df_pois_circle = None

        return df_pois_circle

    def callGGApiCircle(self, query):
        """ Function that retrieve a circle from google maps with all POIs in it.

        :param query: Request format to retrieve a circle from the Google Maps API.
        :type query: String
        :return: A dataframe with all the POIs from the circle requested
        :rtype: pd.DataFrame()
        """
        key = "AIzaSyBIfEtTd1A-qnM0D0VUIalclev648OkORk"  # TODO: Save it in a file (preferably encrypted)

        # Split search request's parameters
        query_parts = query.split('&')
        location = query_parts[0]
        radius = query_parts[1]
        type = query_parts[2]

        # Retrieve values from query to google API Call
        # Get category
        type_value = type.split('type=')[1]
        # Get location data
        location_value = location.split('location=')[1]
        # Get coordinates from location and then, separate lat and lon to a List type
        coordinates = location_value.split(',')

        # Get radius data
        radius_value = radius.split('radius=')[1]
        radius_int_value = int(radius_value.split('.')[0])

        try:
            # Starting Google's client with a Google's API key
            # ToDo: put this into de apiKeys.ini file
            gmaps = googlemaps.Client(key=key)

            # Calling the API from Google and returned in a dict
            places_nearby = gmaps.places_nearby(
                location=coordinates, radius=radius_int_value, type=type_value)

            # Convert results to DataFrame
            df_gg_results = pd.DataFrame(places_nearby['results'])

        except Exception as e:
            logging.error(e)
            logging.error("An error happened while calling GG API")
            df_gg_results = None

        return df_gg_results

    def reset_csv(self):
        """[summary]
        """
        # Initiate dataframe for the poi results that has been scraped
        df_poi_results_template = pd.DataFrame(columns=[
            'Name',
            'Total reviews',
            'GG First review',
            'GG Last review',
            'GG Business status',
            'GG Permanently closed',
            'GG lat',
            'GG lon',
            'Category',
            'GG Types',
            'GG Opening hours',
            'GG POI Id',
            'Older than a year'
        ])

        csv_file_path = params['path_to_csv_vm'] + \
            "web_scrapped_pois_{0}.csv".format(self.search_type)
        # Headers added to the CSV file where to store all POI scraped
        df_poi_results_template.to_csv(
            csv_file_path, index=False, encoding='utf-8')

    def save_to_csv(self, row, params):
        """[summary]
        """

        # Initiate dataframe for the poi results that has been scraped
        df_poi_results = pd.DataFrame(columns=[
            'Name',
            'Total reviews',
            'GG First review',
            'GG Last review',
            'GG Business status',
            'GG Permanently closed',
            'GG lat',
            'GG lon',
            'Category',
            'GG Types',
            'GG Opening hours',
            'GG POI Id',
            'Older than a year'
        ])

        # Save web scraping result into a dataframe
        df_poi_results['Name'] = [row['name']]
        df_poi_results['Total reviews'] = [
            webDriverIntance.location_data.get('reviews_count')]

        if webDriverIntance.location_data.get('rating') == '':
            df_poi_results['GG First review'] = ['False']
        else:
            df_poi_results['GG First review'] = [
                webDriverIntance.location_data.get('Reviews')[-1].get('date')]

        if webDriverIntance.location_data.get('rating') == '':
            df_poi_results['GG Last review'] = ['False']
        else:
            df_poi_results['GG Last review'] = [
                webDriverIntance.location_data.get('Reviews')[0].get('date')]

        df_poi_results['GG Business status'] = [row['business_status']]

        if 'permanently_closed' in row:
            df_poi_results['GG Permanently closed'] = [row['permanently_closed']
                                                       ] if row['permanently_closed'] is not np.nan else ['False']
        else:
            df_poi_results['GG Permanently closed'] == ['False']

        df_poi_results['GG lat'] = [row['geometry'].get('location').get('lat')]
        df_poi_results['GG lon'] = [row['geometry'].get('location').get('lng')]
        df_poi_results['Category'] = [self.search_type]
        df_poi_results['GG Types'] = [row['types']]
        df_poi_results['GG Opening hours'] = [row['opening_hours']
                                              ] if row['opening_hours'] is not np.nan else ['False']
        df_poi_results['GG POI Id'] = [row['reference']]
        df_poi_results['Older than a year'] = '{older}'.format(
            older=self.older_than_a_year)

        # Append into one sigle dataframe with all the results
        logging.info("Saving POIS web scraped results into a CSV file...")

        csv_file_path = params['path_to_csv_vm'] + \
            "web_scrapped_pois_{0}.csv".format(self.search_type)
        df_poi_results.to_csv(csv_file_path, mode="a",
                              index=False, encoding='utf-8', header=False)

        logging.info("POIs results saved in {0}".format(csv_file_path))

    def get_truncated_normal(self, mean=0, sd=1, low=0, upp=10):
        """ Function that given a mean, a standard deviation, a lower bound and a upper bound, 
        returns a number within the gauss distribution bounded given.

        :param mean: Mean of the distribution, defaults to 0
        :type mean: int, optional
        :param sd: Standard deviation of the distribution, defaults to 1
        :type sd: int, optional
        :param low: Lower bound of the gauss distribution, defaults to 0
        :type low: int, optional
        :param upp: Upper bound of the gauss distribution, defaults to 10
        :type upp: int, optional
        :return: Random number from a Gauss disribution with the setted boundries, mean and standard deviation
        :rtype: double
        """
        return truncnorm(
            (low - mean) / sd, (upp - mean) / sd, loc=mean, scale=sd)


def scrape_from_gg_circles(web_driver_instance: WebDriver, query_circle: str, user_agent: str, options: Options):
    """[summary]

    :param web_driver_instance: [description]
    :type web_driver_instance: WebDriver
    :param query_circle: [description]
    :type query_circle: str
    :param user_agent: [description]
    :type user_agent: str
    :param options: [description]
    :type options: Options
    :return: [description]
    :rtype: [type]
    """
    # Reset CSV file first, where all web scraping results will be stored
    web_driver_instance.reset_csv()

    df_gg_circle = web_driver_instance.callGGApiCircle(
        query=query_circle)

    try:

        # Do web scraping for the POIs retrieved in the new GG API call (same parameters as
        # the DDBB GG API Call)
        for index, row in df_gg_circle.iterrows():
            logging.debug(
                "POI: {0} - Number: {1}".format(row['name'], index))

            # GG place ID
            place_id = row['place_id']

            # Concatenate Google Maps URL and the POI to be web scraped
            url_to_web_scrape = google_maps_url + place_id + driver_language

            # Creates a new instance of the webdriver with a new agent different from previuse one (to avoid getting exposed as a robot)
            options.add_argument(
                'user-agent={user_agent}'.format(user_agent=user_agent))
            driver = webdriver.Chrome(
                chrome_options=options)
            new_web_driver_instance = WebDriver(
                driver=driver, search_type=webDriverIntance.search_type)

            # Do web scraping
            new_web_driver_instance.scrape(url_to_web_scrape)

            # Save results into a DataFrame to save it later to CSV file.
            new_web_driver_instance.save_to_csv(row=row, params=params)

            # Generates random numbers with a normal/gaussian distribution, bounded between 2 and 10, and centered in 7
            gauss_rand = new_web_driver_instance.get_truncated_normal(
                mean=5, sd=2, low=2, upp=10)
            pause_time = gauss_rand.rvs()

            time.sleep(pause_time)

            # Closing the driver
            new_web_driver_instance.driver.quit()

    except Exception as e:
        logging.error(e)
        logging.error(
            "Something went wrong when scraping... moving to the next POI...")
        new_web_driver_instance = None

    return new_web_driver_instance


def get_phatomJS_driver():
    """[summary]

    :return: [description]
    :rtype: [type]
    """
    # Phantom
    driver = webdriver.PhantomJS(service_args=['--load-images=no'])
    driver = webdriver.PhantomJS()

    # Randomize IP address and add it to the Chrome Driver
    # PROXY = proxies[0].get_address()
    # webdriver.DesiredCapabilities.CHROME['proxy'] = {
    #     "httpProxy": PROXY,
    #     "ftpProxy": PROXY,
    #     "sslProxy": PROXY,

    #     "proxyType": "MANUAL",

    # }
    webdriver.DesiredCapabilities.CHROME['acceptSslCerts'] = True

    return driver


def get_tor_driver():
    """[summary]

    :return: [description]
    :rtype: [type]
    """
    # TOR + Chrome webdriver
    torexe = os.popen(r'/usr/local/Cellar/tor/0.4.6.5/bin/tor')
    PROXY = "socks5://localhost:9050"  # IP:PORT or HOST:PORT
    options = webdriver.ChromeOptions()
    options.add_argument('--proxy-server=%s' % PROXY)
    driver = webdriver.Chrome(chrome_options=options)
    # Check Tor driver
    driver.get("http://check.torproject.org")

    return driver


def get_chrome_driver():
    # Multi-agent chromedriver
    options = Options()
    ua = UserAgent()
    user_agent = ua.random
    logging.info(user_agent)
    options.add_argument(
        'user-agent={user_agent}'.format(user_agent=user_agent))
    # Check if the webdriver is going to be headless or not
    if params['headless'] == 'True':
        options.add_argument('--headless')

    driver = webdriver.Chrome(chrome_options=options)

    return driver, options, user_agent


def create_gg_circles_api_queries(row: dict):
    """ Function that generates a query string for the Google Maps Circle search API endpoint.

    :param row: A row from the input csv file with all the circles to web scrape (each row is a circle)
    :type row: dict
    :return: String query for the Google Maps Circle search API endpoint
    :rtype: str
    """

    gg_api_circle_query = "location={lat},{lon}&radius={radius}&type={type}".format(
        lat=row['lat'], lon=row['lon'], radius=row['radius'], type=row['category'])

    return gg_api_circle_query


if __name__ == "__main__":

    # Start this dataframe as None value
    df_pois_circle = None

    # Start chrono to measure elapsed time
    start = time.time()
    # ToDo: Fix it. weird format time.
    logging.info("Starting time at: {0}".format(start))

    # Get scraper configuration from config.ini file
    params = config(section='scraper_config')

    # Type of web scraping
    web_scraping_type = params['circles_type']

    # Category to search
    # category = params['circles_category']

    # Type of webdriver's agent
    webdriver_agent = params['webdriver_agent']

    # Initialize driver for web scraping.
    if webdriver_agent == 'phantomjs':
        # Phantom
        driver = get_phatomJS_driver()

    elif webdriver_agent == 'tor':
        # TOR + Chrome webdriver
        driver = get_tor_driver()

    elif webdriver_agent == 'chrome':
        # Multi-agent chromedriver
        driver, options, user_agent = get_chrome_driver()

    # Setting request language
    driver_language = "&hl=en"

    # Create instance for the Web Scraper
    webDriverIntance = WebDriver(driver=driver, search_type=None)

    # Web scrape POIs from new circles randomly retrieved from Google API calls
    if web_scraping_type == "gg_circles":

        df_gg_circles = pd.read_csv(
            params['path_to_input_vm'], sep=';', usecols=['lat', 'lon', 'radius', 'category'])

        for index, row in df_gg_circles.iterrows():
            # Generating query string for the Google Maps Circle search API endpoint
            query_circle = create_gg_circles_api_queries(row=row)
            # Set up the category of the circle (POI's type)
            webDriverIntance.search_type = row['category']

            # Doing web scraper from each google circle
            webDriverIntance = scrape_from_gg_circles(
                web_driver_instance=webDriverIntance, query_circle=query_circle, user_agent=user_agent, options=options)

    else:

        # Connect to PostgreSQL DDBB and return cursor to operate with it
        cursor = connect_to_postgreSQL()
        logging.debug(cursor)

        # Get first circle given a category
        sample_circle = webDriverIntance.get_circle_from_postgreSQL(
            cursor=cursor, category=webDriverIntance.search_type)

        # It needs to make another cursor to re-connect to the postgreSQL
        cursor = connect_to_postgreSQL()
        logging.debug(cursor)

        # Get POIs from a given circle/sample_id.
        df_pois_circle = webDriverIntance.get_pois_from_circle(
            cursor=cursor, sample_id=sample_circle)

    if df_pois_circle is not None:

        # Check if it is required to web scrape circles from the DDBB only or circles from a new call to GG or both
        # circle.
        # Web scrape both circles (postgreSQL DDBB circles and GG API Circles)
        if web_scraping_type == 'both':

            # Circle from postgreSQL DDBB
            # For each POI in circle, do web scraping.
            for index, row in df_pois_circle.iterrows():
                # POI id from google maps
                poi_id = row['poi_id']

                # Concatenate Google Maps URL and the POI to be web scraped
                url_to_web_scrape = google_maps_url + poi_id + driver_language
                # Do web scraping
                webDriverIntance.scrape(url_to_web_scrape)

            # Call Google API for nearby places (circle) # ToDo: must be called from a APIcall library
            # Retrieve request search done in the past from the postgreSQL to re-do the google API and
            # compare circles.
            query_circle = row['search_request_string']
            df_gg_circle = webDriverIntance.callGGApiCircle(
                query=query_circle)

            # Do web scraping for the POIs retrieved in the new GG API call (same parameters as
            # the DDBB GG API Call)
            for index, row in df_gg_circle.iterrows():
                place_id = row['place_id']
                # Concatenate Google Maps URL and the POI to be web scraped
                url_to_web_scrape = google_maps_url + place_id + driver_language

                # Do web scraping
                webDriverIntance.scrape(url_to_web_scrape)

                # Generates random numbers with a normal/gaussian distribution, bounded between 2 and 10, and centered in 7
                gauss_rand = webDriverIntance.get_truncated_normal(
                    mean=5, sd=2, low=2, upp=10)
                pause_time = gauss_rand.rvs()

                time.sleep(pause_time)

            # Save results into a DataFrame to save it later to CSV file.
            webDriverIntance.save_to_csv(row=row, params=params)
            time.sleep(pause_time)

            # Closing the driver
            webDriverIntance.driver.quit()

        # Web scrape only the new circle retrieve from GG API call.
        elif web_scraping_type == 'new':
            # Call Google API for nearby places (circle) # ToDo: must be called from a APIcall library
            # Retrieve request search done in the past from the postgreSQL to re-do the google API and
            # compare circles.
            query_circle = df_pois_circle['search_request_string'][0]
            df_gg_circle = webDriverIntance.callGGApiCircle(
                query=query_circle)

            # Do web scraping for the POIs retrieved in the new GG API call (same parameters as
            # the DDBB GG API Call)
            for index, row in df_gg_circle.iterrows():
                logging.debug(
                    "POI: {0} - Number: {1}".format(row['name'], index))

                # GG Id.
                place_id = row['place_id']

                # Concatenate Google Maps URL and the POI to be web scraped
                url_to_web_scrape = google_maps_url + place_id + driver_language

                # Creates a new instance of the webdriver with a new agent different from previouse one (to avoid getting exposed as a robot)
                options.add_argument(
                    'user-agent={user_agent}'.format(user_agent=user_agent))
                driver = webdriver.Chrome(
                    chrome_options=options)
                webDriverIntance = WebDriver(
                    driver=driver, search_type=webDriverIntance.search_type)

                # Do web scraping
                webDriverIntance.scrape(url_to_web_scrape)

                # Save results into a DataFrame to save it later to CSV file.
                webDriverIntance.save_to_csv(row=row, params=params)

                # Generates random numbers with a normal/gaussian distribution, bounded between 2 and 10, and centered in 7
                gauss_rand = webDriverIntance.get_truncated_normal(
                    mean=5, sd=2, low=2, upp=10)
                pause_time = gauss_rand.rvs()

                time.sleep(pause_time)

                # Closing the driver
                webDriverIntance.driver.quit()

    else:
        logging.error("No circle found in PostgreSQL Database")

    logging.info("FINISHED!")

    # Time elapsed
    end = time.time()
    time_elapsed = end - start
    logging.info("Total time elapsed: {0} seconds".format(time_elapsed))


if __name__ == '__main__':
    connect_to_postgreSQL()
import logging
from unidecode import unidecode
import re

class Sanitizer:

    @staticmethod
    def _punctuation_table() -> dict:
        """
        Create puntuation table dictionary.

        :return: punctuation_table
        :rtype: dict
        """
        strange_char_space = r"!#$%&()*+,./:;<=>?@[\]^_{|}~ºª®-"
        char_2_remove = "\"'^`"
        space_mask = "                                "
        punctuation_table = str.maketrans(strange_char_space, space_mask,
                                            char_2_remove)

        return punctuation_table

    @classmethod
    def normalize_char(cls, name: list) -> list:
        """
        Takes one column (name of the POI) and it does some transformation.
        :return: Column transformed (POI name) 
        

        :param name: List of string/s (ideally incoming from a column).
        :type name: list
        :return: Transformed list of string/s.
        :rtype: list
        """
        try:
            punctuation_table = cls._punctuation_table()

            if not name != name:
                name = name.lower()
                name = name.strip()
                name = unidecode(name)
                name = name.translate(punctuation_table)
                name = re.sub(r' +', ' ', name)
                name = name.strip()
                name = name.lower()
        except Exception as e:
            logging.error(e)
            print(e)
            name = ''

        return name

    @classmethod
    def udf_normalize_char(cls, in_df, in_col_name: str, out_col_name: str):
        # Initiate UDF
        udf_normalise_char = udf(lambda x: cls.normalize_char(x), StringType())
    
        # Apply UDF function
        out_df = in_df.withColumn(out_col_name, udf_normalise_char(col(in_col_name)))
        return out_df

    @classmethod
    def translate_to_latin(cls, in_string:str) -> str:
        """_summary_

        :param in_string: _description_
        :type in_string: _type_
        :return: _description_
        :rtype: _type_
        """

        out_string = unidecode(in_string)

        return out_string
    

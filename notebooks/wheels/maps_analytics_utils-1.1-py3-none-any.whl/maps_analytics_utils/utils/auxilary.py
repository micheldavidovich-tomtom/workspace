import datetime
import requests
import json


def get_today_date() -> str:
    date_value = datetime.datetime.now().strftime('%Y%m%d')
    return date_value


def manual_create_run_id(response: int, date: str, digits_len_int: int) -> str:
    run_id_value = date+"-"+format(response+1, "0" + str(digits_len_int))
    return run_id_value


def extract_map_version_from_api(url: str) -> str:
    """ Function that extracts the map version from the TomTom api endpoint /2/ or the
    Openmap api endpoint /10/. The current function to simplify the process considers
    USA's map version as the standard.

    :param url: Input url of the api endpoint url.
    :type url: str
    :return: A string with the map version of that api endpoint.
    :rtype: str
    """
    try:
        response = requests.get(url)
        if response.status_code == 200:
            json_response = json.loads(response.text)
        else:
            json_response = None
        if json_response != None:
            try:
                for item in json_response['versions']['map']['geoPoliticalViews']['Unified']['countries']:
                    if len(item) > 0:
                        my_dict = item
                        map_version = my_dict['map']
                        break
                    else:
                        map_version = None
            except (Exception) as error:
                print("Error - JSON:", error)
    except (Exception) as error:
        print("Error - Requests:", error)
    return map_version


def get_map_version(provider: str) -> str:
    """ The function calls and extracts the map version of the api endpoints. The two possible input
    providers "tt" or "openmap" are currenlty the endpoint available to extract the map version.

    :param provider: String input with either "tt" or "openmap".
    :type provider: str
    :return: A string with the map version of that api endpoint.
    :rtype: str
    """
    try:
        if provider == "tt":
            url = "https://api.tomtom.com/search/2/search/version?key=o4ZWqM50QH3QuXT2oAccHjmGBgvTwP21"
            map_version = extract_map_version_from_api(url)
        if provider == "openmap":
            url = "https://api.tomtom.com/search/10/search/version?key=o4ZWqM50QH3QuXT2oAccHjmGBgvTwP21"
            map_version = extract_map_version_from_api(url)
    except (Exception) as error:
        map_version = None
        print("Error - No Provider:", error)
    return map_version
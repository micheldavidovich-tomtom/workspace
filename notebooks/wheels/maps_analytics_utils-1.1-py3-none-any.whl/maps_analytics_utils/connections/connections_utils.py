# -*- coding: utf-8 -*-
"""
The main purpose of this script, is to encapsulate all the generic functions used
by adls.py and postgresql.py scripts.
Credits:
    -------
    Author: Lucas Mengual (@LucasMengual-TomTom)
    License: MIT License 2021
    Reference:
    ----------
    [1] https://docs.python.org/3/library/configparser.html
    [2] https://docs.python.org/3/library/pkgutil.html
"""


from configparser import ConfigParser
import pkgutil


# within package/mymodule1.py, for example
configfile = pkgutil.get_data(__name__, 'connections.cfg').decode()
configfile_mcp = pkgutil.get_data(__name__, 'connections_mcp.cfg').decode()


# create a parser
cfg = ConfigParser()
cfg_mcp = ConfigParser()


# read config file
cfg.read_string(configfile)
cfg_mcp.read_string(configfile_mcp)


def get_poi_secrets():
    """
    Function that reads the connections.cfg file in order to access the secrets for
    accessing the POI postgres server.

    :return: user: Output string with the username to access the postgres server.
    :return: password: Output string with the password to access the postgres server.
    :return: port: Integers with the port (default is 5432) to access the postgres server.
    :return: database: Output string with the DDBB database name of the postgres server.
    :return: host: Output string with the host name of the postgres server.
    :return: url: Output string with url to the posgres server, including the host, port, and database information.
    """
    user = cfg.get("POI", "user", raw="")
    password = cfg.get("POI", "pass", raw="")
    port = cfg.get("POI", "port", raw="")
    database = cfg.get("POI", "database", raw="")
    host = cfg.get("POI", "host", raw="")
    url = "jdbc:postgresql://{0}:{1}/{2}".format(host, port, database)
    return user, password, port, database, host, url


def get_assr_secrets():
    """
    Function that reads the connections.cfg file in order to access the secrets for
    accessing the ASSR postgres server.

    :return: user: Output string with the username to access the postgres server.
    :return: password: Output string with the password to access the postgres server.
    :return: port: Integers with the port (default is 5432) to access the postgres server.
    :return: database: Output string with the DDBB database name of the postgres server.
    :return: host: Output string with the host name of the postgres server.
    :return: url: Output string with url to the posgres server, including the host, port, and database information.
    """
    user = cfg.get("ASSR", "user", raw="")
    password = cfg.get("ASSR", "pass", raw="")
    port = cfg.get("ASSR", "port", raw="")
    database = cfg.get("ASSR", "database", raw="")
    host = cfg.get("ASSR", "host", raw="")
    url = "jdbc:postgresql://{0}:{1}/{2}".format(host, port, database)
    return user, password, port, database, host, url


def get_adls_poi_raw():
    """
    Function that reads the connections.cfg file in order to access the secrets for
    connections with POI´s Azure Data Lake Service (ADLS) raw container, which are
    maintained by the App Registration service.

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: secret_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg.get("ADLS_POI_RAW", "tenant_id", raw="")
    client_id = cfg.get("ADLS_POI_RAW", "client_id", raw="")
    secret_value = cfg.get("ADLS_POI_RAW", "secret_value", raw="")
    secret_id = cfg.get("ADLS_POI_RAW", "secret_id", raw="")
    return tenant_id, client_id, secret_value, secret_id


def get_adls_poi_no_raw():
    """
    Function that reads the connections.cfg file in order to access the secrets for
    connections with POI´s Azure Data Lake Service (ADLS) bronze, silver, and gold containers,
    which are maintained by the App Registration service.

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: secret_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg.get("ADLS_POI_NO_RAW", "tenant_id", raw="")
    client_id = cfg.get("ADLS_POI_NO_RAW", "client_id", raw="")
    secret_value = cfg.get("ADLS_POI_NO_RAW", "secret_value", raw="")
    secret_id = cfg.get("ADLS_POI_NO_RAW", "secret_id", raw="")
    return tenant_id, client_id, secret_value, secret_id


def get_adls_poi_rw():
    """
    Function that reads the connections.cfg file in order to access the secrets for
    connections with POI´s Azure Data Lake Service (ADLS) raw container, which are
    maintained by the App Registration service.

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: secret_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg.get("ADLS_POI_RW", "tenant_id", raw="")
    client_id = cfg.get("ADLS_POI_RW", "client_id", raw="")
    secret_value = cfg.get("ADLS_POI_RW", "secret_value", raw="")
    secret_id = cfg.get("ADLS_POI_RW", "secret_id", raw="")
    return tenant_id, client_id, secret_value, secret_id


def get_adls_assr_raw():
    """
    Function that reads the connections.cfg file in order to access the secrets for
    connections with ASSR´s Azure Data Lake Service (ADLS) raw container, which are
    maintained by the App Registration service.

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: secret_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg.get("ADLS_ASSR_RAW", "tenant_id", raw="")
    client_id = cfg.get("ADLS_ASSR_RAW", "client_id", raw="")
    secret_value = cfg.get("ADLS_ASSR_RAW", "secret_value", raw="")
    secret_id = cfg.get("ADLS_ASSR_RAW", "secret_id", raw="")
    return tenant_id, client_id, secret_value, secret_id


def get_adls_assr_no_raw():
    """
    Function that reads the connections.cfg file in order to access the secrets for
    connections with ASSR´s Azure Data Lake Service (ADLS) bronze, silver, and gold containers,
    which are maintained by the App Registration service.

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: secret_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg.get("ADLS_ASSR_NO_RAW", "tenant_id", raw="")
    client_id = cfg.get("ADLS_ASSR_NO_RAW", "client_id", raw="")
    secret_value = cfg.get("ADLS_ASSR_NO_RAW", "secret_value", raw="")
    secret_id = cfg.get("ADLS_ASSR_NO_RAW", "secret_id", raw="")
    return tenant_id, client_id, secret_value, secret_id

def get_poi_rw():
    """
    Function that reads the connections_mcp.cfg file in order to access the secrets for
    connections with POI´s Azure Data Lake Service (ADLS) container, with read and write 
    permissions, which are maintained by MCP. 

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: object_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg_mcp.get("POI_RW", "tenant_id", raw="")
    client_id = cfg_mcp.get("POI_RW", "client_id", raw="")
    secret_value = cfg_mcp.get("POI_RW", "secret_value", raw="")
    object_id = cfg_mcp.get("POI_RW", "object_id", raw="")
    return tenant_id, client_id, secret_value, object_id

def get_poi_r():
    """
    Function that reads the connections_mcp.cfg file in order to access the secrets for
    connections with POI´s Azure Data Lake Service (ADLS) container, with read 
    permissions, which are maintained by MCP. 

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: object_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg_mcp.get("POI_R", "tenant_id", raw="")
    client_id = cfg_mcp.get("POI_R", "client_id", raw="")
    secret_value = cfg_mcp.get("POI_R", "secret_value", raw="")
    object_id = cfg_mcp.get("POI_R", "object_id", raw="")
    return tenant_id, client_id, secret_value, object_id


def get_addressing_rw():
    """
    Function that reads the connections_mcp.cfg file in order to access the secrets for
    connections with Addressing Azure Data Lake Service (ADLS) container, with read and write 
    permissions, which are maintained by MCP. 

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: object_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg_mcp.get("ADDRESSING_RW", "tenant_id", raw="")
    client_id = cfg_mcp.get("ADDRESSING_RW", "client_id", raw="")
    secret_value = cfg_mcp.get("ADDRESSING_RW", "secret_value", raw="")
    object_id = cfg_mcp.get("ADDRESSING_RW", "object_id", raw="")
    return tenant_id, client_id, secret_value, object_id


def get_maps_gold_r():
    """
    Function that reads the connections_mcp.cfg file in order to access the secrets for
    connections with the gold layer Maps Azure Data Lake Service (ADLS) container, with read 
    permissions, which are maintained by MCP. 

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: object_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg_mcp.get("MAPS_GOLD_R", "tenant_id", raw="")
    client_id = cfg_mcp.get("MAPS_GOLD_R", "client_id", raw="")
    secret_value = cfg_mcp.get("MAPS_GOLD_R", "secret_value", raw="")
    object_id = cfg_mcp.get("MAPS_GOLD_R", "object_id", raw="")
    return tenant_id, client_id, secret_value, object_id


def get_maps_gold_rw():
    """
    Function that reads the connections_mcp.cfg file in order to access the secrets for
    connections with the gold layer Maps Azure Data Lake Service (ADLS) container, with read and write 
    permissions, which are maintained by MCP. 

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: object_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg_mcp.get("MAPS_GOLD_RW", "tenant_id", raw="")
    client_id = cfg_mcp.get("MAPS_GOLD_RW", "client_id", raw="")
    secret_value = cfg_mcp.get("MAPS_GOLD_RW", "secret_value", raw="")
    object_id = cfg_mcp.get("MAPS_GOLD_RW", "object_id", raw="")
    return tenant_id, client_id, secret_value, object_id


def get_addressing_r():
    """
    Function that reads the connections_mcp.cfg file in order to access the secrets for
    connections with Addressing Azure Data Lake Service (ADLS) container, with read 
    permissions, which are maintained by MCP. 

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Output string with the secret value of the app registration.
    :return: object_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = cfg_mcp.get("ADDRESSING_R", "tenant_id", raw="")
    client_id = cfg_mcp.get("ADDRESSING_R", "client_id", raw="")
    secret_value = cfg_mcp.get("ADDRESSING_R", "secret_value", raw="")
    object_id = cfg_mcp.get("ADDRESSING_R", "object_id", raw="")
    return tenant_id, client_id, secret_value, object_id


def check_name(name):
    """
    Function to check if the name (poi or assr) of the metric is correct, otherwise
    raise an Exception message.

    :param name: Input string with either "poi" or "assr" options accepted
    """
    list_of_accepted_names = ["poi", "assr"]
    if name in list_of_accepted_names:
        return True
    else:
        raise Exception("""name should be either "poi" or "assr".""")


def check_input(input):
    """
    Function to check if the input (local or azure) name is correct, otherwise
    raise an Exception message.

    :param input: Input string with either "local" or "azure" options accepted
    """
    list_of_accepted_inputs = ["local", "azure"]
    if input in list_of_accepted_inputs:
        return True
    else:
        raise Exception("""input should be either "local" or "azure".""")


#TODO
# Function to be deprecated
def check_container(container):
    """
    Function to check if the container (raw, bronze, silver, or gold) name is correct,
    otherwise raise an Exception message.

    :param container: Input string with either "raw", "bronze", "silver", or "gold" options accepted
    """
    list_of_accepted_containers = ["raw", "bronze", "silver", "gold"]
    if container in list_of_accepted_containers:
        return True
    else:
        raise Exception("""container should be either "raw", "bronze", "silver", or "gold".""")


def get_adx_secrets():
    """
    Function that reads the connections.cfg file in order to access the secrets for
    connections with ASSR´s Azure Data Lake Service (ADLS) bronze, silver, and gold containers,
    which are maintained by the App Registration service.

    :return: tenant_id: Output string with the Tenant ID of TomTom.
    :return: client_id: Output string with the Client ID of the app registration.
    :return: secret_value: Empty string, since is not required, otherwise in app registration.
    :return: secret_id: Output string with the secret identifier of the app registration.
    """
    tenant_id = "374f8026-7b54-4a3a-b87d-328fa26ec10d"
    client_id = "4f8a3735-861a-4b79-9daa-9e9365b77348"
    secret_value = ""
    secret_id = "r6zvtc-Y4UJTI.2CqQN~VW-ir-suAAIk6K"
    return tenant_id, client_id, secret_value, secret_id
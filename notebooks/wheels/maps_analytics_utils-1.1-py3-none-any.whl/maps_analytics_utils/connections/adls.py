# -*- coding: utf-8 -*-
"""
The main purpose of this script, is to encapsulate all the functionalities for
Azure Data Lake Service (ADLS Gen 2) connections. Letting the user to read, write, edit (depending on their
permissions in the case of azure).
Credits:
    -------
    Author: Lucas Mengual (@LucasMengual-TomTom)
    License: MIT License 2021
    Reference:
    ----------
    [1] https://docs.databricks.com/_static/notebooks/dbutils.html
"""


from ..utils import spark_utils
from .connections_utils import check_container

import typing
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType


def set_config(tenant_id: str, client_id: str, secret_value: str) -> typing.Dict:
    """Function that initiates config setting for ADLS connectivity in order to mount the container
    into the DBFS mount point.

    :param tenant_id: Input string with the Tenant ID of TomTom.
    :type tenant_id: str
    :param client_id: Input string with the Client ID of the app registration.
    :type client_id: str
    :param secret_value: Input string with the secret value of the app registration.
    :type secret_value: str
    :return: configs: Output <dict> type with all the configuration settings.
    :rtype: typing.Dict
    """
    configs = {"fs.azure.account.auth.type": "OAuth",
               "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
               "fs.azure.account.oauth2.client.id": client_id,
               "fs.azure.account.oauth2.client.secret": secret_value,
               "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/"+tenant_id+"/oauth2/token",
               "fs.azure.createRemoteFileSystemDuringInitialization": "true"}
    return configs


def mount_adls_to_mnt(configs: typing.Dict, container: str, storage: str, mount_point: str = None, spark: SparkSession = None):
    """
    Function that mounts into DBFS mount point, based in the configs settings,
    container and storage names.

    :param configs: Input <dict> type with all the configuration settings.
    :type: typing.Dict
    :param container: Input string with the Container name to be mounted.
    :type container: str
    :param storage: Input string with the ADLS Storage account name to be mounted.
    :type storage: str
    :param mount_point: Input string with the mount point name that will associate the ADLS container in Spark.
    :type mount_point: str
    :param spark: Spark session.
    :type spark: SparkSession
    """
    try:
        dbutils = spark_utils.get_dbutils(spark)
        if mount_point != None:
            dbutils.fs.mount(source="abfss://"+container+"@"+storage+".dfs.core.windows.net/",
                            mount_point="/mnt/"+mount_point,
                            extra_configs=configs)
            print("Successfully mounted %s container from %s storage in DBFS /mnt/%s" % (container, storage, mount_point))
        else:
            dbutils.fs.mount(source="abfss://"+container+"@"+storage+".dfs.core.windows.net/",
                            mount_point="/mnt/"+container,
                            extra_configs=configs)
            print("Successfully mounted %s container from %s storage in DBFS /mnt/%s" % (container, storage, container))
    except:
        raise Exception("Error while mounting from adls to DBFS mount point.")


def unmount_mnt_from_adls(container: str, spark: SparkSession = None):
    """
    Function that unmounts the DBFS mount point. It only requires the container name,
    which is associated with the mount path is located in DBFS (i.e. /mnt/CONTAINER_NAME).

    :param container: Input string with the Container name to be unmounted.
    :type container: str
    :param spark: Spark session.
    :type spark: SparkSession
    """
    try:
        dbutils = spark_utils.get_dbutils(spark)
        dbutils.fs.unmount(mount_point="/mnt/"+container)
    except:
        raise Exception("Error unmounting from DBFS mount point (check if container name is correct).")


def upload_to_adls(input_df: DataFrame, file_path: str, partition_list: typing.List[str], mode: str = "append", schema: typing.Optional[StructType] = None):
    """PySpark function which upload pyspark dataframe to ADLS. Make sure to have the mount to ADLS connection
    before executing ths function. The function requires the pyspark dataframe, path in ADLS, 
    list with string values with the column names to which partition de dataset, and mode in to which 
    upload the dataset (i.e. append, overwrite, etc).

    :param input_df: Input pyspark dataframe.
    :type input_df: pyspark.sql.DataFrame
    :param file_path: Input string which corresponds to the path in ADLS to store the dataframe.
    :type file_path: str
    :param partition_list: List with string values that correspond to the dataframe column names to make the partition by.
    :type partition_list: list[str]
    :param mode: Input string which mode parameter value. Defaults to "append".
    :type mode: str, optional
    :param schema: Input schema related to the input pyspark dataframe. Defaults to None.
    :type mode: pyspark.sql.types.StructType, optional
    """
    if schema:
        try:
            input_df.write.format("delta").option("header", "true").schema(schema).partitionBy([x for x in partition_list]).mode(mode).save(file_path)
            print("Finished uploading dataframe to ADLS!")
        except Exception as err:
            print(f"Error while uploading data to ADLS: {err}")
    else:
        try:
            input_df.write.format("delta").option("header", "true").partitionBy([x for x in partition_list]).mode(mode).save(file_path)
            print("Finished uploading dataframe to ADLS!")
        except Exception as err:
            print(f"Error while uploading data to ADLS: {err}")


def remove_directory_from_adls(path: str, spark: SparkSession = None) -> bool:
    """Removes a file or directory.

    :param path: Absolute path of the directory or file
    :type path: str
    :param spark: Spark session
    :type spark: SparkSession
    :return: Does the directory or file exist?
    :rtype: bool
    """
    dbutils = spark_utils.get_dbutils(spark)
    result = dbutils.fs.rm(path, True)
    if result:
        print("Directory or file deleted successfully")
    else:
        print("Directory or file not found")
    return result

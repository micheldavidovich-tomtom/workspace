# -*- coding: utf-8 -*-
"""
The main purpose of this script, is to encapsulate all schema information and types required for the
migration of the data related to the ASSR/addresses metric.
Credits:
    -------
    Author: Lucas Mengual (@LucasMengual-TomTom)
    License: MIT License 2021
    Reference:
    ----------
    [1] https://docs.python.org/3/library/datetime.html
    [2] https://spark.apache.org/docs/latest/api/python/reference/index.html
"""

from datetime import datetime
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType
from pyspark.sql.functions import col, split, lit, regexp_replace

assr_reference_gg_schema = StructType(fields=[StructField('reference_id', StringType(), True),
                                              StructField('project_id', StringType(), True),
                                              StructField('provider_id', StringType(), True),
                                              StructField('address_id', StringType(), True),
                                              StructField('region', StringType(), True),
                                              StructField('country', StringType(), True),
                                              StructField('quality', StringType(), True),
                                              StructField('source', StringType(), True),
                                              StructField('formatted_address', StringType(), True),
                                              StructField('address_components', StringType(), True),
                                              StructField('location', StringType(), True),
                                              StructField('gal', StringType(), True),
                                              StructField('search_id', LongType(), True),
                                              StructField('origin', StringType(), True)])


#(20210506-001)

def check_if_ap1_run_id_exists(input_df):
    """
    Function that checks inside the PySpark dataframe schema if the api1_run_id
    column exists and return True if so.

    :param input_df: A table in <pyspark.sql.dataframe.DataFrame> format
    """
    if StructField("api1_run_id", StringType(), True) in input_df.schema:
        return True
    else:
        raise Exception("""The "api1_run_id" column is not found.""")

#TODO
# check id inside the master table (not combined_q1_q4)

def find_api1_run_id(input_df, date_value):
    input_df_null_filter =  input_df.where(col("api1_run_id").isNotNull())
    #TODO
    # shouldn´t be using count()
    if input_df_null_filter.count() > 0:
        split_col = split(input_df['api1_run_id'], '-')
        splitted_df = input_df_null_filter.withColumn('date', split_col.getItem(0)).withColumn('id', split_col.getItem(1))
        checked_splitted_df = splitted_df.where(col("date").isin({date_value}))
        if checked_splitted_df.count() > 0:
            checked_splitted_df = checked_splitted_df.withColumn("id", checked_splitted_df["id"].cast(IntegerType()))
            response = checked_splitted_df.agg({"id": "max"}).collect()[0][0]
        else:
            response = 0
    else:
        #response = "all_null"
        response = 0
    return response


def get_today_date():
    date_value = datetime.now().strftime('%Y%m%d')
    return date_value

def create_api1_run_id(response):
    ap1_run_id_value = get_today_date()+"-"+format(response+1, "04")
    return ap1_run_id_value


def manual_create_api1_run_id(response, date):
    ap1_run_id_value = date+"-"+format(response+1, "04")
    return ap1_run_id_value


def convert_geos_to_lat_long(input_df, target_column):
    input_df = input_df.withColumn('chopped_geos', split(input_df[target_column], 'POINT').getItem(1))\
        .withColumn("chopped_geos", regexp_replace(regexp_replace("chopped_geos", "\\(", ""), "\\)", ""))
    split_col = split(input_df['chopped_geos'], ' ')
    input_df = input_df.withColumn('lat', split_col.getItem(2))\
        .withColumn('long', split_col.getItem(1))
    output_df = input_df.drop(target_column).drop("chopped_geos")
    return output_df

def store_api1_run_id(input_df):
    """

    """
    # if check_if_ap1_run_id_exists(input_df):
    #    response = find_api1_run_id(input_df)
    #    api1_run_id_value = create_api1_run_id(response)
    #    output_df = input_df.withColumn("api1_run_id", lit(api1_run_id_value))
    check_if_ap1_run_id_exists(input_df)
    response = find_api1_run_id(input_df)
    api1_run_id_value = create_api1_run_id(response)
    output_df = input_df.withColumn("api1_run_id", lit(api1_run_id_value))
    output_df = convert_geos_to_lat_long(output_df, "location")
    return output_df



# -*- coding: utf-8 -*-
"""
The main purpose of this script, is to encapsulate all schema information and types required for the
migration of the data related to the ASSR/addresses metric.
Credits:
    -------
    Author: Lucas Mengual (@LucasMengual-TomTom)
    License: MIT License 2021
    Reference:
    ----------
    [1] https://pandas.pydata.org/pandas-docs/stable/reference/index.html#api
"""

#TODO
# add generic migrations function in here


#def get_today_date()
#def create_api1_run_id()
#def manual_create_api1_run_id()
#def convert_geos_to_lat_long()

import pandas as pd
import numpy as np
import country_converter
import geopandas as gpd
import shapely
from addressing.utils import dbconnection
from addressing.rca.mnr import convert_coordinates_to_query
from addressing.automatic_matching.rooftop.rooftop import haversine_distance
from map_content.utils import utils
from fuzzywuzzy import fuzz
from rapidfuzz import process
from rapidfuzz.fuzz import token_set_ratio
import unidecode 
import re 
import typing 
import ast 


def find_osm_schema(country:str, latest:bool or None=True, source:str ='clean') -> pd.DataFrame:
    """Gets the schema in the OSM's 3G database to make a spatial query

    :param country: country code in ISO2 or ISO3
    :type country: str
    :param latest: boolean or None indicating whether to return the latest version of OSM product, defaults to True
    :type latest: bool or None, optional
    :param source: 'clean' or 'raw'. String indicating which OSM to query (source or clean), defaults to 'clean'
    :type source: str or None, optional
    :return: DataFrame with the relevant country schemas
    :rtype: pd.DataFrame
    """
    
    
    # Standarize country input to ISO3
    country_iso3 = country_converter.convert(country, to='ISO3')
    
    
    # Get the db to query
    if source=='clean':
        db = 'osm-clean'
    elif source=='raw':
        db = 'osm-source'
    
    
    # Query all schemas in OSM database
    _, conn = dbconnection.connect('../sql/database.ini', db)
    schemas_df = pd.read_sql('SELECT nspname FROM pg_catalog.pg_namespace', 
                             conn)
    conn.close()
    
    # Filter relevant country
    country_schemas = (schemas_df
                    .loc[schemas_df.nspname.str.contains(country_iso3, 
                                                            case=False)]
                    .reset_index(drop=True)
                    )

    
    country_schemas['date'] = country_schemas.nspname.str.extract('([0-9]+)')
    country_schemas['schema'] = country_schemas.nspname.str.replace('_[0-9]+.*', '', regex=True)
    country_schemas['is_latest'] = country_schemas.date==country_schemas.groupby('schema').date.max()[0]

    # Return schemas
    if latest:
        return country_schemas.loc[country_schemas.is_latest==latest].reset_index(drop=True)
    else:
        return country_schemas
    

def osm_lookup(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, radius:int or float=50,
               inner_radius:int or float=0, source:str ='clean') -> pd.DataFrame:
    """Performs spatial queries of a list of coordinates in MNR to get the APTs near the addresses
    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the addresses to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param radius: radius in meters to look around the coordinates to retrieve the nearby APTs,  defaults to 50
    :type radius: int or float, optional
    :param inner_radius: inner radius in meters to look distances bigger than this APT, defaults to 0
    :type inner_radius: int or float, optional
    :param source: 'clean' or 'raw'. String indicating which OSM to query (source or clean), defaults to 'clean'
    :type source: str, optional
    :return: APTs in OSM near the coordinates
    :rtype: pd.DataFrame
    """


    # Create query for addresses to reverse lookup
    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                         from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    
    
    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Get the db to query
    if source=='clean':
        db = 'osm-clean'
    elif source=='raw':
        db = 'osm-source'
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', db)
        
        query_buffers = """
        with sample as ({query_coordinates})
        
        , tags as (
        select distinct skeys(tags) keys
        from {schema}.planet_osm_polygon pop 
        where admin_level  in ('4', '8')
        )

        , name_tags as (
        select * 
        from tags
        where (keys like '%name:%' or keys like '%alt%name') and keys not like '%pronunciation%'
        )     

        , buffers as (
            select 
                sample.index_searched_query
            ,   sample.coordinates
            ,   ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
            ,   postcode.postcode as postal_code
            ,   city.name as city_name
            ,	city.name_tags_array as city_names
            ,   state.name as state_name
            ,	state.name_tags_array as state_names
            ,   road.road as road_name
            ,	road.name_tags_array as road_names
            from sample


            left join lateral (
                            SELECT name as road, array_remove(tags->array((select keys from name_tags)), null) as name_tags_array
                            FROM {schema}.planet_osm_line road
                            where name is not null
                            and highway  in ('motorway','motorway_link','trunk','trunk_link','primary','primary_link','secondary','secondary_link','tertiary','tertiary_link','unclassified','residential','service','living_street','road','steps', 'footway', 'path', 'pedestrian', 'bridleway', 'cycleway', 'track')
                            ORDER BY road.way <-> sample.coordinates

                            LIMIT 1
                            ) AS road
            on true


            left outer join(
                        
                select index_searched_query, array_agg(distinct postcode) as postcode 
                from
                        (Select
                        sample.index_searched_query,
                        way,
                    --   array_agg( array_remove(ARRAY[tags->'postal_code',tags->'addr:postal_code',tags->'postcode', tags->'addr:postcode'], null) ) postcode
                        unnest(array_remove(tags->array['postal_code', 'addr:postal_code', 'postcode', 'addr:postcode'], null)) as postcode
                        From {schema}.planet_osm_polygon polygon

                        join sample on ST_Intersects(sample.coordinates, polygon.way)

                        Where (tags?|ARRAY['postal_code','addr:postal_code','postcode','addr:postcode'] AND boundary = 'administrative')
                        OR boundary = 'postal_code'

                        ) a
                
                where postcode is not null
                group by index_searched_query    
                    
                            ) AS postcode
            on postcode.index_searched_query = sample.index_searched_query


            left outer join (
                            select admin_level , place, name, way,
                            array_remove(tags->array((select keys from name_tags)), null) as name_tags_array
                            from {schema}.planet_osm_polygon pop 
                            where admin_level in ('8')
                            and boundary ='administrative'

                            ) city 
            on ST_Intersects(sample.coordinates, city.way)


            left outer join (
                select admin_level , place, name, way,
                array_remove(tags->array((select keys from name_tags)), null) as name_tags_array
                from {schema}.planet_osm_polygon pop 
                where admin_level in ('4')
                and boundary ='administrative'

                ) state 
                    on ST_Intersects(sample.coordinates, state.way)


        )


        select 
            buffers.index_searched_query
        ,   buffers.coordinates
        ,   '{date}' as release_date
        ,   '{version}' as product_version
        ,   st_astext(buffers.buffer) buffer
        , 'point' as type
        , node.osm_id
        , node."access"
        , node."addr:housename"
        , node."addr:housenumber"::text
        , node."addr:interpolation"
        , node.place
        , node.admin_level
        , node.tags
        , st_astext(node.way) geom
        , node.reg_code
        , node.region
        , node.cntry_code
        , node.state_code
        , node.state
        , node.county
        , node.city
        , node.mqs
        , buffers.road_name
        , buffers.road_names
        , buffers.postal_code
        , buffers.city_name
        , buffers.city_names
        , buffers.state_name
        , buffers.state_names
        from buffers

        join {schema}.planet_osm_point node
            on ST_Intersects(buffers.buffer, node.way)


        where ((node."addr:housenumber" is not null and node."addr:housenumber" <> '') or node.tags::text like '%addr%housenumber%')
        and floor(ST_Distance(node.way, buffers.coordinates, true)) >= {inner_radius}


        union all


        select 
            buffers.index_searched_query
        ,   buffers.coordinates
        ,   '{date}' as release_date
        ,   '{version}' as product_version
        ,   st_astext(buffers.buffer) buffer
        , 'building' as point
        , poly.osm_id
        , poly."access"
        , poly."addr:housename"
        , poly."addr:housenumber"::text
        , poly."addr:interpolation"
        , poly.place
        , poly.admin_level
        , poly.tags
        , st_astext(st_centroid(poly.way)) geom
        , poly.reg_code
        , poly.region
        , poly.cntry_code
        , poly.state_code
        , poly.state
        , poly.county
        , poly.city
        , poly.mqs
        , buffers.road_name
        , buffers.road_names
        , buffers.postal_code
        , buffers.city_name
        , buffers.city_names
        , buffers.state_name
        , buffers.state_names
        from buffers

        join {schema}.planet_osm_polygon poly
            on ST_Intersects(buffers.buffer, poly.way)

        where  ((poly."addr:housenumber" is not null and poly."addr:housenumber" <> '') or poly.tags::text like '%addr%housenumber%')
        and  floor(ST_Distance(poly.way, buffers.coordinates, true)) >= {inner_radius} 
        """.format(query_coordinates=query_coordinates,
                   radius=radius, 
                   date=row.date,   
                   schema=row.nspname,
                   version=row.date,
                   inner_radius=inner_radius)

        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_buffers, conn, geom_col='coordinates')
        spatial_query_result['buffer'] = gpd.GeoSeries.from_wkt(spatial_query_result['buffer'])
        spatial_query_result['geom'] = gpd.GeoSeries.from_wkt(spatial_query_result['geom']) 


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)

    return gpd.GeoDataFrame(lookup_df)
    
    
def parse_osm_tags(df:pd.DataFrame) -> pd.DataFrame:
    """Parses the OSM tags to extract address info

    :param df: DataFrame from OSM result
    :type df: pd.DataFrame
    :return: DataFrame with added columns for address components
    :rtype: pd.DataFrame
    """
    
    # Create copy of
    df_copy = df.copy()
    
    
    # Split tags into list
    df_copy['tags_list'] = df_copy.tags.str.split('",')
    df_copy['tags_list'] = df_copy.tags_list.apply(lambda x:  [tag.split('=>') for tag in x])
    
    
    # Parse components
    df_copy['hsn'] = df_copy.tags_list.apply(lambda x: [tag[1].replace('"', '').strip()
                                                  for tag in x if 'housenumber' in tag[0]])
    df_copy['hsn'] = df_copy.hsn.apply(lambda x:  ' '.join(x) if x else None)
    
    df_copy['city'] = df_copy.tags_list.apply(lambda x: [tag[1].replace('"', '').strip() 
                                                                        for tag in x if 'city' in tag[0]])
    df_copy['city'] = df_copy.city.apply(lambda x:  x if x else None)

    df_copy['state'] = df_copy.tags_list.apply(lambda x: [tag[1].replace('"', '').strip() 
                                                                        for tag in x if 'state' in tag[0]])
    df_copy['state'] = df_copy.state.apply(lambda x:  x if x else None)

    df_copy['street'] = df_copy.tags_list.apply(lambda x: [tag[1].replace('"', '').strip() 
                                                                            for tag in x if 'street' in tag[0]])
    df_copy['street'] = df_copy.street.apply(lambda x:  x if x else None)
    
    df_copy['postcode'] = df_copy.tags_list.apply(lambda x: [tag[1].replace('"', '').strip() 
                                                                                for tag in x if 'postcode' in tag[0]])

    df_copy['postcode'] = df_copy.postcode.apply(lambda x: x if x else None)
    
    
    return df_copy.drop(columns='tags_list')
 
 
def poi_osm_lookup(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, radius:int or float=50,  
                   inner_radius:int or float = 0, source:str = 'clean') -> pd.DataFrame:
    """Performs spatial queries of a list of coordinates in OSM to get the APTs near the POI
    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the POIS to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param radius: radius in meters to look around the coordinates to retrieve the nearby POI,  defaults to 50
    :type radius: int or float, optional
    :param inner_radius: inner radius in meters to look distances bigger than this APT, defaults to 0
    :type inner_radius: int or float, optional
    :param source: 'clean' or 'raw'. String indicating which OSM to query (source or clean), defaults to 'clean'
    :type source: str, optional
    :return: POIS in OSM near the coordinates
    :rtype: 
    """ 
    
    
    # Create query for addresses to reverse lookup
    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                         from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    
    
    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', 'osm-clean')
        
        query_buffers = """
        with sample as ({query_coordinates})                       

    , buffers as (
    select  
        sample.index_searched_query
        , sample.coordinates
        , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), 1000), 4326) buffer
    from sample
    )

    select 
        buffers.index_searched_query
    ,   buffers.coordinates
    ,   '{date}' as release_date
    ,   '{version}' as product_version
    ,   st_astext(buffers.buffer) buffer
    , 'point' as type
    , node.osm_id
    , node."access"
    , node."addr:housename"
    , node."addr:housenumber"
    , node."addr:interpolation"
    , node.admin_level
    , node.aerialway
    , node.aeroway
    , node.amenity
    , node.area
    , node.barrier
    , node.bicycle
    , node.brand
    , node.bridge
    , node.boundary
    , node.building
    , node.capital
    , node.construction
    , node.covered
    , node.culvert
    , node.cutting
    , node.denomination
    , node.disused
    , node.ele
    , node.embankment
    , node.foot
    , node."generator:source"
    , node.harbour
    , node.highway
    , node.historic
    , node.horse
    , node.intermittent
    , node.junction
    , node.landuse
    , node.layer
    , node.leisure
    , node."lock"
    , node.man_made
    , node.military
    , node.motorcar
    , node."name"
    , node."natural"
    , node.office
    , node.oneway
    , node."operator"
    , node.place
    , node.population
    , node.power
    , node.power_source
    , node.public_transport
    , node.railway
    , node."ref"
    , node.religion
    , node.route
    , node.service
    , node.shop
    , node.sport
    , node.surface
    , node.toll
    , node.tourism
    , node."tower:type"
    , node.tunnel
    , node.water
    , node.waterway
    , node.wetland
    , node.width
    , node.wood
    , node.z_order
    , node.tags
    , st_astext(node.way) geom
    , node.reg_code
    , node.region
    , node.cntry_code
    , node.state_code
    , node.state
    , node.county
    , node.city
    , node.mqs

    from buffers

    join {schema}.planet_osm_point node
        on ST_Intersects(buffers.buffer, node.way)

    where node.name is not null and node.name <> ''
        

    union all


    select 
        buffers.index_searched_query
    ,   buffers.coordinates
    ,   '{date}' as release_date
    ,   '{version}' as product_version
    ,   st_astext(buffers.buffer) buffer
    , 'building' as point
    , poly.osm_id
    , poly."access"
    , poly."addr:housename"
    , poly."addr:housenumber"
    , poly."addr:interpolation"
    , poly.admin_level
    , poly.aerialway
    , poly.aeroway
    , poly.amenity
    , poly.area
    , poly.barrier
    , poly.bicycle
    , poly.brand
    , poly.bridge
    , poly.boundary
    , poly.building
    , '' as capital
    , poly.construction
    , poly.covered
    , poly.culvert
    , poly.cutting
    , poly.denomination
    , poly.disused
    , '' as ele
    , poly.embankment
    , poly.foot
    , poly."generator:source"
    , poly.harbour
    , poly.highway
    , poly.historic
    , poly.horse
    , poly.intermittent
    , poly.junction
    , poly.landuse
    , poly.layer
    , poly.leisure
    , poly."lock"
    , poly.man_made
    , poly.military
    , poly.motorcar
    , poly."name"
    , poly."natural"
    , poly.office
    , poly.oneway
    , poly."operator"
    , poly.place
    , poly.population
    , poly.power
    , poly.power_source
    , poly.public_transport
    , poly.railway
    , poly."ref"
    , poly.religion
    , poly.route
    , poly.service
    , poly.shop
    , poly.sport
    , poly.surface
    , poly.toll
    , poly.tourism
    , poly."tower:type"
    , poly.tunnel
    , poly.water
    , poly.waterway
    , poly.wetland
    , poly.width
    , poly.wood
    , poly.z_order
    , poly.tags
    , st_astext(st_centroid(poly.way)) geom
    , poly.reg_code
    , poly.region
    , poly.cntry_code
    , poly.state_code
    , poly.state
    , poly.county
    , poly.city
    , poly.mqs

    from buffers

    join {schema}.planet_osm_polygon poly
        on ST_Intersects(buffers.buffer, poly.way)

    where poly.name is not null and poly.name <> ''
        """.format(query_coordinates=query_coordinates,
                   radius=radius, 
                   date=row.date,                   
                   schema=row.nspname,
                   version=row.nspname)
        
    
    # Query database
    spatial_query_result = gpd.GeoDataFrame.from_postgis(query_buffers, conn, geom_col='coordinates')
    spatial_query_result['buffer'] = gpd.GeoSeries.from_wkt(spatial_query_result['buffer'])
    spatial_query_result['geom'] = gpd.GeoSeries.from_wkt(spatial_query_result['geom']) 
    
    
    # Concat responses
    lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
    conn.close()

    
    return gpd.GeoDataFrame(lookup_df)
     

def osm_call_radius(df:pd.DataFrame, country:str, libpostal_df:pd.DataFrame, 
                    radius:int or float, inner_radius:int or float = 0, 
                    stopwords_pattern:str = '', source:str = 'clean') -> pd.DataFrame:
    """Finds APTs in OSM PBF at a given radius

    :param df: DataFrame containing sample addresses with reference coordinates in a column named 'coordinates'
    :type df: pd.DataFrame
    :param country: ISO2 or ISO3 of the country
    :type country: str
    :param libpostal_df: libpostal containing the address components of the sample addresses in 'df'. Used for matching
    :type libpostal_df: pd.DataFrame
    :param radius: radius in which APTs from the PBF will be returned
    :type radius: int or float
    :param inner_radius: inner radius in meters to look distances bigger than this APT, defaults to 0
    :type inner_radius: int or float, optional
    :param stopwords_pattern: regex pattern to remove stopwords, if needed. Optional, defaults to None
    :type stopwords_pattern: str
    :param source: 'clean' or 'raw'. String indicating which OSM to query (source or clean), defaults to 'clean'
    :type source: str, optional
    :return: tuple of DataFrames, first one for the matched APTs and second one for all APTS returned by the PBF
    :rtype: typing.Tuple[pd.DataFrame, pd.DataFrame]
    """
    
    df_copy = df.copy()
    
    # Minimum columns the last DF must have
    cols_final = ['country','searched_query',  'partition_id', 'lat','lon','searched_query_unidecode', 'release_date', 'product_version',
                    'type', 'osm_id', 'tags', 'address', 'osm_lat', 'osm_lon', 'match', 'osm_query_distance', 'mean_similarity',
                    'addr_housenumber', 'road_component','city_component', 'postcode_similarity_best_score', 'state_component', 'locality_similarity',
                   'road_similarity', 'postcode_similarity', 'hsn_similarity','road_names', 'city_names', 'state_names']

    
    country_schemas = find_osm_schema(country, latest=True, source=source)
    lookup_df = osm_lookup(coordinates=df_copy.coordinates, schemas=country_schemas, radius=radius, 
                           inner_radius=inner_radius, source=source)
    lookup_df = lookup_df.drop_duplicates(['index_searched_query', 'osm_id']).reset_index(drop=True)
    lookup_df['postal_code'] = lookup_df.postal_code.apply(lambda x: x[0] if x else None)
    
    
    # Parse the resulting tags
    lookup_df = parse_osm_tags(lookup_df)
    lookup_df.columns = [col.replace(':', '_') for col in lookup_df.columns]
    
    
    # Merge to get original queries information
    lookup_df_merged = lookup_df.merge(df_copy[['searched_query', 'lat', 'lon', 'searched_query_unidecode']].drop_duplicates().reset_index(drop=True),
                                       how='right', 
                                       left_on='index_searched_query', 
                                       right_index=True).reset_index(drop=True)

    lookup_df_merged['osm_lat'] = lookup_df_merged.geom.apply(lambda p: p.y if p else 9999)
    lookup_df_merged['osm_lon'] = lookup_df_merged.geom.apply(lambda p: p.x if p else 9999)
    lookup_df_merged['osm_query_distance'] = lookup_df_merged.apply(lambda x: haversine_distance(x.osm_lat, 
                                                                                                 x.osm_lon,
                                                                                                 x.lat, 
                                                                                                 x.lon)
                                                                  if not np.isnan(x.lat) else 1e7
                                                                  , axis=1)

    apts_df_lookup = lookup_df_merged.copy().rename(columns={'country':'country_osm'})
    apts_df_lookup['country'] = country


    # Replace columns names
    apts_df_lookup.columns = [col.replace(':', '_') for col in apts_df_lookup.columns]
   
   
    # Imputation of components based on spatial queries results
    apts_df_lookup['addr_housenumber'] = np.where(apts_df_lookup.addr_housenumber.isna(), apts_df_lookup.hsn, apts_df_lookup.addr_housenumber) 
    apts_df_lookup['street'] = np.where(apts_df_lookup.street.isna(), apts_df_lookup.road_names, apts_df_lookup.street)
    apts_df_lookup['city'] = np.where(apts_df_lookup.city.isna(), apts_df_lookup.city_names, apts_df_lookup.city)
    apts_df_lookup['state'] = np.where(apts_df_lookup.state.isna(), apts_df_lookup.state_names, apts_df_lookup.state)
    apts_df_lookup = apts_df_lookup.loc[~apts_df_lookup.addr_housenumber.isna()].reset_index(drop=True)

    if apts_df_lookup.shape[0] == 0:
        print(f'{radius}m  done!')
        
        # Imputation of missing columns
        df_copy = df_copy.assign(match=0)
        
        for col in [col for col in cols_final if col not in df_copy.columns]:
            df_copy[col] = pd.NA
        
        return df_copy
        
        
    # Imputation of postal code and transform to list
    apts_df_lookup['postcode'] = apts_df_lookup.postcode.fillna(apts_df_lookup.postal_code)
    apts_df_lookup['postcode'] = apts_df_lookup.postcode.apply(lambda x: [x] if not isinstance(x, list) else x)


    # Merge to libpostal
    apts_df_lookup = apts_df_lookup.merge(libpostal_df.drop(columns=['country', 'searched_query_unidecode']).astype(str),
                                          how='left', 
                                          on='searched_query')

    
    # Compute hsn similarity and filter obvious non matches
    apts_df_lookup['libpostal_house_number_numeric'] = utils.get_numeric_house_number_column(apts_df_lookup.libpostal_house_number)
    apts_df_lookup['addr_housenumber_numeric'] = utils.get_numeric_house_number_column(apts_df_lookup.addr_housenumber)
    
    
    apts_df_lookup['hsn_similarity'] = apts_df_lookup.apply(lambda x: fuzz.token_set_ratio(x.libpostal_house_number_numeric,  
                                                                                                                    x.addr_housenumber_numeric), axis=1)
    apts_df_lookup['addr_housenumber'] = apts_df_lookup.addr_housenumber.str.replace('[\+\*\.\?\(\)\[\]\$\^\|\{\}]','', regex=True).str.replace('\\', '', regex=False)
    apts_df_lookup['re_pattern'] = '\\b' + apts_df_lookup.addr_housenumber.astype(str) + '\\b'
    apts_df_lookup['hsn_in_query'] = apts_df_lookup.apply(lambda x: bool(re.search(x.re_pattern, x.searched_query)), axis=1)
    apts_df_lookup['hsn_similarity'] = np.where((apts_df_lookup.hsn_in_query), 100, apts_df_lookup.hsn_similarity)
    apts_df_lookup = apts_df_lookup.loc[apts_df_lookup.hsn_similarity >= 70].reset_index(drop=True)
                                                                                                                    
    if apts_df_lookup.shape[0] > 0:                                                                                                          
        # Create unidecode no stopwords columns
        cols_components = ['street', 'city', 'state']
        for col in cols_components:
            col_create = col + '_no_stopwords'
            col_stopwords = col + '_unidecode_no_stopwords'
            apts_df_lookup[col_create] = apts_df_lookup[col].apply(lambda x: [re.sub(stopwords_pattern,'',j)
                                                                              for j in x] if x else '')
            
            apts_df_lookup[col_stopwords] = apts_df_lookup[col].apply(lambda x: [re.sub(stopwords_pattern, '', 
                                                                                        unidecode.unidecode(j))
                                                                                 for j in x] if x else '')


        # Measure by components
        # Street
        apts_df_lookup['road_unidecode_similarity'] = apts_df_lookup.apply(lambda x: process.extractOne(x.libpostal_road_no_stopwords,
                                                                                                        x.street_unidecode_no_stopwords), axis=1)
        apts_df_lookup['road_similarity'] = (apts_df_lookup
                                            .apply(lambda x: process.extractOne(x.libpostal_road_no_stopwords,
                                                                                x.street_no_stopwords), axis=1)
                                            )

        # Postcode
        apts_df_lookup['postcode_similarity'] = apts_df_lookup.apply(lambda x: process.extractOne(x.libpostal_postcode,
                                                                                                x.postcode), axis=1)


        # Locality match up
        apts_df_lookup['libpostal_locality'] = apts_df_lookup.libpostal_city_no_stopwords +  ' ' +  apts_df_lookup.libpostal_state_no_stopwords


        cols_localities = ['city', 'state']
        for col in cols_localities:
            apts_df_lookup[col+'_unidecode_similarity'] = apts_df_lookup.apply(lambda x: process.extractOne(x.libpostal_locality,
                                                                                                            x[col+'_unidecode_no_stopwords']), axis=1)
            apts_df_lookup[col+'_similarity'] = apts_df_lookup.apply(lambda x: process.extractOne(x.libpostal_locality,
                                                                                                x[col+'_no_stopwords']), axis=1)

        # Get best similarities columns
        cols_similarities = [col for col in apts_df_lookup.columns if '_similarity' in col and not 'similarity_' in col and not 'hsn' in col]
        for col in cols_similarities:
            best_score = col + '_best_score'
            score_col = col + '_score'
            
            apts_df_lookup[best_score] = apts_df_lookup[col].apply(lambda x: x[0] if x else '')
            apts_df_lookup[score_col] = apts_df_lookup[col].apply(lambda x: x[1] if x else np.nan)


        for col in ['road', 'city', 'state']:
            apts_df_lookup[f'{col}_similarity'] = apts_df_lookup[[f'{col}_similarity_score', 
                                                                                            f'{col}_unidecode_similarity_score']].max(axis=1)
            apts_df_lookup[f'{col}_component'] = np.where((apts_df_lookup[f'{col}_similarity_score'] > 
                                                                        apts_df_lookup[f'{col}_unidecode_similarity_score']),
                                                                        apts_df_lookup[f'{col}_similarity_best_score'], 
                                                                        apts_df_lookup[f'{col}_unidecode_similarity_best_score'])
            
        # Compute locality similarity as the token set ratio of city + state
        apts_df_lookup['locality_similarity'] = list(map(fuzz.token_set_ratio, apts_df_lookup.libpostal_locality, 
                                                                    apts_df_lookup.city_component + ' ' + apts_df_lookup.state_component))


        # Compute similarity for postcode
        apts_df_lookup['postcode_similarity'] = np.where(apts_df_lookup.libpostal_postcode=='',
                                                                    np.nan,
                                                                    np.where((apts_df_lookup.postcode.isna()) | (apts_df_lookup.postcode==''), 50,
                                                                                apts_df_lookup.postcode_similarity_score))

        # Compute mean similarity
        apts_df_lookup = apts_df_lookup.sort_values(by='osm_query_distance').reset_index(drop=True)
        apts_df_lookup['mean_similarity'] = (apts_df_lookup[['locality_similarity', 'hsn_similarity', 'postcode_similarity', 'road_similarity']].mean(axis=1)
                                                        * np.where(apts_df_lookup.hsn_similarity >= 85 , 1, 0)
                                                        * np.where(apts_df_lookup.road_similarity >= 70, 1, 0) 
                                                        * np.where(apts_df_lookup.osm_query_distance > 1000, 0, 1))
        
        # Pump obvious matches 
        apts_df_lookup['mean_similarity'] = np.where((apts_df_lookup.road_similarity >= 85) & (apts_df_lookup.hsn_similarity > 90), 100, apts_df_lookup.mean_similarity)
        apt_lookup_match_df = apts_df_lookup.loc[apts_df_lookup.groupby('searched_query').mean_similarity.idxmax()].reset_index(drop=True)
        apt_lookup_match_df['match'] = np.where(apt_lookup_match_df.mean_similarity >= 70, 1, 0)
        apt_lookup_match_df['address'] =  (apt_lookup_match_df.addr_housenumber + ' ' +  apt_lookup_match_df.road_component + ' ' + 
                                        apt_lookup_match_df.postcode_similarity_best_score + ' ' + apt_lookup_match_df.city_component + ' ' +
                                        apt_lookup_match_df.state_component)
        
        apt_lookup_match_df = df_copy[['searched_query', 'country']].merge(apt_lookup_match_df, on=['searched_query', 'country'], how='left')
        apt_lookup_match_df['match'] = apt_lookup_match_df.match.fillna(0)
        
        print(f'{radius}m  done!')
        return apt_lookup_match_df
    else:
        print(f'{radius}m  done!')
        
        # Imputation of missing columns
        df_copy = df_copy.assign(match=0)
        for col in [col for col in cols_final if col not in df_copy.columns]:
            df_copy[col] = pd.NA
        
        return df_copy


def osm_hnr_lookup(coordinates:gpd.GeoSeries, 
                   schemas:pd.DataFrame, source:str = 'clean') -> gpd.GeoDataFrame:
    """Performs spatial queries on a list of coordinates to find the HNR 
    in OSM format

    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the APTs to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param source: 'clean' or 'raw'. String indicating which OSM to query (source or clean), defaults to 'clean'
    :type source: str, optional
    :return: points in OM near the coordinates
    :rtype: gpd.GeoDataFrame
    """
    
    # Create query for addresses to reverse lookup
    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                         from """ + utils.convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    
    
    # Initialize connection to OSM
    if source=='clean':
        db = 'osm-clean'
    elif source=='raw':
        db = 'osm-source'
        
    _, conn = dbconnection.connect('../sql/database.ini', db)
    
    
    # Create DataFrame to get results
    lookup_df = pd.DataFrame()
    
    # Iterate over schemas and databases to make spatial queries
    for _, row in schemas.iterrows():
        query = """
        with sample as ({query_coordinates})
        
        , tags as (
        select distinct skeys(tags) keys
        from {schema}.planet_osm_polygon pop 
        where admin_level  in ('4', '8')
        )

        , name_tags as (
        select * 
        from tags
        where (keys like '%name:%' or keys like '%alt%name') and keys not like '%pronunciation%'
        )   
        
    , buffers as (
            select 
                sample.index_searched_query
            ,   sample.coordinates
            ,   ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), 1000), 4326) buffer
            ,   postcode.postcode as postal_code
            ,   city.name as city_name
            ,	city.name_tags_array as city_names
            ,   state.name as state_name
            ,	state.name_tags_array as state_names
            ,   road.road as road_name
            ,	road.name_tags_array as road_names
            from sample


            left join lateral (
                            SELECT name as road, array_remove(tags->array((select keys from name_tags)), null) as name_tags_array
                            FROM {schema}.planet_osm_line road
                            where name is not null
                            and highway  in ('motorway','motorway_link','trunk','trunk_link','primary','primary_link','secondary','secondary_link','tertiary','tertiary_link','unclassified','residential','service','living_street','road','steps', 'footway', 'path', 'pedestrian', 'bridleway', 'cycleway', 'track')
                            ORDER BY road.way <-> sample.coordinates

                            LIMIT 1
                            ) AS road
            on true


            left outer join(
                        
                select index_searched_query, array_agg(distinct postcode) as postcode 
                from
                        (Select
                        sample.index_searched_query,
                        way,
                    --   array_agg( array_remove(ARRAY[tags->'postal_code',tags->'addr:postal_code',tags->'postcode', tags->'addr:postcode'], null) ) postcode
                        unnest(array_remove(tags->array['postal_code', 'addr:postal_code', 'postcode', 'addr:postcode'], null)) as postcode
                        From {schema}.planet_osm_polygon polygon

                        join sample on ST_Intersects(sample.coordinates, polygon.way)

                        Where (tags?|ARRAY['postal_code','addr:postal_code','postcode','addr:postcode'] AND boundary = 'administrative')
                        OR boundary = 'postal_code'

                        ) a
                
                where postcode is not null
                group by index_searched_query    
                    
                            ) AS postcode
            on postcode.index_searched_query = sample.index_searched_query


            left outer join (
                            select admin_level , place, name, way,
                            array_remove(tags->array((select keys from name_tags)), null) as name_tags_array
                            from {schema}.planet_osm_polygon pop 
                            where admin_level in ('8')
                            and boundary ='administrative'

                            ) city 
            on ST_Intersects(sample.coordinates, city.way)


            left outer join (
                select admin_level , place, name, way,
                array_remove(tags->array((select keys from name_tags)), null) as name_tags_array
                from {schema}.planet_osm_polygon pop 
                where admin_level in ('4')
                and boundary ='administrative'

                ) state 
                    on ST_Intersects(sample.coordinates, state.way)
        )  
        
        
        select 
            hsn.osm_id
        ,   hsn.index_searched_query
        ,   '{date}' as date
        ,   '{version}' as version
        ,   hsn.coordinates
        ,   hsn.postal_code
        ,   hsn.city_name
        ,   hsn.city_names
        ,   hsn.state_name
        ,   hsn.state_names
        ,   hsn.road_name
        ,   hsn.road_names
        ,	hsn.tags as tags_network
        ,   hsn.road_name_way
        ,   hsn.interpolation
        ,   hsn.way
        ,   hsn.name
        ,	min(point."addr:housenumber") as min_hsn
        ,   max(point."addr:housenumber") as max_hsn
        ,   array_agg(distinct point."addr:housenumber") as intermediates
        from

        (
        select 
            buffers.index_searched_query
        ,   buffers.coordinates
        ,   buffers.postal_code
        ,   buffers.city_name
        ,   buffers.city_names
        ,   buffers.state_name
        ,   buffers.state_names
        ,   buffers.road_name
        ,   buffers.road_names
        ,   hnr.osm_id
        ,	ST_astext(hnr.way) way
        ,	hnr."addr:interpolation" as interpolation
        ,   hnr.tags
        ,	hnr.tags->'addr:street' as road_name_way
        ,   hnr."name" 
        ,	unnest(ways.nodes) nodes

        from {schema}.planet_osm_line hnr
        
        join buffers on ST_Intersects(buffers.buffer, hnr.way)

        join {schema}.planet_osm_ways ways  on ways.id = hnr.osm_id

        where hnr."addr:interpolation"  in ('all', 'even', 'odd') 
        ) hsn 

        left join {schema}.planet_osm_point point 
            on hsn.nodes = point.osm_id 
            
        where point."addr:housenumber" is not null  
        and point."addr:housenumber" not like '%;%' --TODO: better treat these cases

        group by 
            hsn.osm_id
        ,   hsn.index_searched_query
        ,   hsn.coordinates
        ,   hsn.postal_code
        ,   hsn.city_name
        ,   hsn.city_names
        ,   hsn.state_name
        ,   hsn.state_names
        ,   hsn.road_name
        ,   hsn.road_names
        ,	hsn.tags 
        ,   hsn.road_name_way
        ,   hsn.interpolation
        ,	hsn.way
        ,   hsn.name
            """.format(query_coordinates=query_coordinates,
                        date=row.date,   
                        schema=row.nspname,
                        version=row.date)
            
        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query, conn, geom_col='coordinates')


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        
    
    conn.close()
    
    return gpd.GeoDataFrame(lookup_df)


def osm_recursive_radius_calls(df:pd.DataFrame, country:str, libpostal_df:pd.DataFrame, 
                               radius_list:typing.List[float], stopwords_pattern:str = '',
                               source:str = 'clean') -> pd.DataFrame:
    """Makes recursive calls to OSM's PBF to get matching APTs

    :param df: DataFrame containing sample addresses with reference coordinates in column 'coordinates'
    :type df: pd.DataFrame
    :param country:  country in ISO2 or ISO3 format
    :type country: str
    :param libpostal_df: libpostal containing the address components of the sample addresses in 'df'. Used for matching
    :type libpostal_df: pd.DataFrame
    :param radius_list: list of raidus to look for APTs in the Openmap's PBF
    :type radius_list: typing.List[float]
    :param stopwords_pattern: regex pattern to remove stopwords, if needed. Optional, defaults to None
    :type stopwords_pattern: str
    :param source: 'clean' or 'raw'. String indicating which OSM to query (source or clean), defaults to 'clean'
    :type source: str, optional
    :return: tuple of DataFrames, first one for the matched APTs and second one for all APTS returned by the PBF
    :rtype: pd.DataFrame
    """
    
    df_copy = df.copy()
    
    
    # Compute first result
    radius_result = osm_call_radius(df_copy, country, libpostal_df, radius_list[0], 0, stopwords_pattern, source)
    apt_match_df = radius_result.loc[radius_result.match==1].reset_index(drop=True)
    missing_apts_df = df_copy.loc[~df_copy.searched_query.isin(apt_match_df.searched_query)].reset_index(drop=True)
    
    
    # Compute remaining results for other radius
    if len(radius_list) > 1 and missing_apts_df.shape[0] > 0:
        for idx, radius in enumerate(radius_list[1:]):
            radius_result = osm_call_radius(missing_apts_df, country, libpostal_df, radius,
                                            radius_list[idx]-5, stopwords_pattern, source)
            matching_found = radius_result.loc[radius_result.match==1].reset_index(drop=True)

                
            # Concatenate to existing DF
            apt_match_df = pd.concat([apt_match_df, matching_found], ignore_index=True)
            missing_apts_df = df_copy.loc[~df_copy.searched_query.isin(apt_match_df.searched_query)].reset_index(drop=True)
            
    # Add latest results but missing
    radius_result['match'] = radius_result.match.fillna(0)
    matching_not_found = radius_result.loc[radius_result.match==0].reset_index(drop=True)
    apt_match_df = pd.concat([apt_match_df, matching_not_found], ignore_index=True)
    
    
    # Merge back to original dataframe and fill NA with 0s
    apt_match_df = df_copy.merge(apt_match_df.drop(columns=['lat', 'lon',  'coordinates', 'searched_query_unidecode']),
                                 on=['searched_query', 'country'],
                                 how='left')
    apt_match_df['match'] = apt_match_df.match.fillna(0)


    return apt_match_df



def appPandas_lookup_components(df:pd.DataFrame, source:str = 'clean') -> pd.DataFrame:
    """Paralelizes the lookup of components by address

    :param df: DataFrame containing lat and lon coordinates of the original full address
    :type df: pd.DataFrame
    :param credentials: dictionary containing credentials to postgres db, defaults to None
    :type credentials: dict, optional
    :return: DataFrame containing the components of the coordinates looked up
    :rtype: pd.DataFrame
    """
    df_copy = df.copy() 
    
    # Get country
    country = df_copy.country.unique()[0]
    
    # Get schema
    schema = find_osm_schema(country, source=source)
    
    # Create coordinates and gpd
    df_copy['coordinates'] = df_copy.apply(lambda x: shapely.geometry.Point(x.lon, x.lat), axis=1)
    gdf_copy = gpd.GeoDataFrame(df_copy, geometry='coordinates')
    
    # Call function and merge to get searched query
    results_gdf = lookup_osm_components(coordinates=gdf_copy.coordinates, schemas=schema, source=source)
    results_gdf = results_gdf.merge(gdf_copy[['searched_query', 'lat', 'lon']], 
                                    how='right',
                                    left_on='index_searched_query', right_index=True)
    
    # Drop columns
    results_gdf = results_gdf.drop(columns=['index_searched_query', 'buffer'])
    results_gdf['country'] = country
    
    # Order columns and return
    columns = ['searched_query', 'country', 'lat', 'lon', 'coordinates', 'date', 'version','postal_code', 'admin_level_2_name',
           'array_admin_level_2_name','admin_level_4_name', 'array_admin_level_4_name', 'admin_level_5_name','array_admin_level_5_name',
           'admin_level_6_name','array_admin_level_6_name', 'admin_level_7_name','array_admin_level_7_name', 'admin_level_8_name','array_admin_level_8_name',
           'admin_level_9_name','array_admin_level_9_name', 'admin_level_10_name','array_admin_level_10_name', 'road_name', 'road_names','localities_array', 
           'postal_code_extended']
    
    return pd.DataFrame(results_gdf[columns]).fillna('').astype(str)


def lsf_matching(df:pd.DataFrame) -> pd.DataFrame:
    """Function used in the pyspark ApplyInPandas() function. Also the function applies the normalization, matching,
    and final values selction of the results.

    :param df: Input of the ApplyInPandas() that must be in pd.DataFrame format.
    :type df: pd.DataFrame
    :return: Output of the ApplyInPandas() that must be in pd.DataFrame format, otherwise empty dataframe with same columns is returned.
    :rtype: pd.DataFrame
    """
    
    cols_select = ['country', 'sample_id', 'searched_query', 'searched_query_type',
                   'lat', 'lon', 'version', 'address', 'match',
                   'array_admin_level_2_name', 'array_admin_level_7_name',
                   'array_admin_level_8_name', 'array_admin_level_9_name',
                   'localities_array', 'partition_id']
  
  
    # MATCHING
    country_locality_df = df.copy()
    partition_id = country_locality_df.partition_id.iloc[0]
    
    
    # Convert the arrays to list type
    cols = ['road_name', 'road_names', 'postal_code', 'postal_code_extended', 'admin_level_2_name', 'localities_array'] + [col for col in country_locality_df.columns if 'array_' in col]
    for col in cols:
        country_locality_df[col] = country_locality_df[col].apply(lambda x: ast.literal_eval(x) if x != '' else [])
    
    country_locality_df.postal_code = country_locality_df.postal_code.apply(lambda x: x[0] if x else '')

  
    country_locality_df['searched_query'] = country_locality_df.searched_query.str.replace("\\bnan\\b|\\bundefined\\b", '', regex=True).str.strip()
    country_locality_df['array_admin_level_2_name'] = country_locality_df.apply(lambda x: x.array_admin_level_2_name + x.admin_level_2_name, axis=1)
    country_locality_df = country_locality_df.drop(columns='admin_level_2_name')
    
    # Impute NAs
    cols_locality = [col for col in country_locality_df.columns if 'admin' in col] + ['localities_array']
    country_locality_df[cols_locality] = country_locality_df[cols_locality].fillna('')
    
    # Create unidecode columns
    for col in cols_locality:
        col_create = col + '_unidecode'

        if 'array' in col:
            country_locality_df[col_create] = country_locality_df[col].apply(lambda x: [unidecode.unidecode(j) for j in x] if x else '')
        else:
            country_locality_df[col_create] = country_locality_df[col].apply(lambda x: unidecode.unidecode(x) if x else '')
    
    # Compute similarities for both unidecode columns
    for col in cols_locality:
        col_create = col + '_similarity'
        col_unidecode_create = col + '_unidecode_similarity'

        if 'array' in col:
            country_locality_df[col_create] = country_locality_df.apply(lambda x: process.extractOne(x.searched_query, x[col]), axis=1)
            country_locality_df[col_unidecode_create] = country_locality_df.apply(lambda x: process.extractOne(x.searched_query, x[col+'_unidecode']), axis=1)  
        else:
            country_locality_df[col_create+'_score'] = country_locality_df.apply(lambda x: fuzz.WRatio(x.searched_query, x[col]), axis=1)
            country_locality_df[col_create+'_best_admin'] = country_locality_df[col]
            country_locality_df[col_unidecode_create+'_score'] = country_locality_df.apply(lambda x: fuzz.WRatio(x.searched_query, x[col+'_unidecode']), axis=1)  
            country_locality_df[col_unidecode_create+'_best_admin'] = country_locality_df[col+'_unidecode']
    
    # Parse localities similarities
    cols_similarities = [col for col in country_locality_df.columns if '_similarity' in col and 'array' in col and 'similarity_' not in col]
    for col in cols_similarities:
        best_admin_col = col + '_best_admin'
        score_col = col + '_score'

        country_locality_df[best_admin_col] = country_locality_df[col].apply(lambda x: x[0] if x else '')
        country_locality_df[score_col] = country_locality_df[col].apply(lambda x: x[1] if x else np.nan)
    
    # Get max score
    cols_score = [col for col in country_locality_df.columns if 'similarity' in col and 'score' in col and 'admin_level_2' not in col]
    country_locality_df['similarity'] = country_locality_df[cols_score].max(axis=1)
    country_locality_df['idx_max'] = country_locality_df[cols_score].idxmax(axis=1).str.replace('_score', '_best_admin')
    country_locality_df = country_locality_df.loc[country_locality_df.groupby('searched_query').similarity.idxmax()].reset_index(drop=True)
    country_locality_df['match'] = np.where(country_locality_df.similarity > 60, 1, 0)
    country_locality_df['country_match'] = np.where((country_locality_df.match == 0) & (country_locality_df.array_admin_level_2_name_unidecode_similarity_score >= 95),
                                                    1,0) 
    country_locality_df['match'] = np.where((country_locality_df.match == 0) & (country_locality_df.array_admin_level_2_name_unidecode_similarity_score >= 95),
                                            1, 
                                            country_locality_df.match)
    
    # Get name 
    country_locality_df['address'] = [country_locality_df.loc[idx, country_locality_df.idx_max[idx]] for idx, row in country_locality_df.iterrows()]
    country_locality_df['address'] = country_locality_df.address + ' ' + country_locality_df.country.str.upper()
    
    # Fix country match
    country_locality_df['address'] = np.where(country_locality_df.country_match==1, country_locality_df.array_admin_level_2_name_unidecode_similarity_best_admin,
                                              country_locality_df.address)

    # Get final columns with desired schema
    country_locality_df['partition_id'] = partition_id
    country_locality_df = country_locality_df[cols_select]

    # Make sure to cast as DF
    country_locality_df = pd.DataFrame(country_locality_df)

    return country_locality_df.fillna('').astype(str)


def psf_matching(df:pd.DataFrame) -> pd.DataFrame:
    """
    Function used in the pyspark ApplyInPandas() function. Also the function applies the normalization, matching,
    and final values selction of the results.

    :param df: Input of the ApplyInPandas() that must be in pd.DataFrame format.
    :type df: pd.DataFrame
    :return: Output of the ApplyInPandas() that must be in pd.DataFrame format, otherwise empty dataframe with same columns is returned.
    :rtype: pd.DataFrame
    """

    cols_select = ['country', 'sample_id', 'searched_query', 'searched_query_type',
                   'lat', 'lon', 'version', 'address', 'match',
                   'array_admin_level_2_name', 'array_admin_level_7_name',
                   'array_admin_level_8_name', 'array_admin_level_9_name',
                   'localities_array', 'partition_id']

    country_locality_pc_df = df.copy()
    partition_id = country_locality_pc_df.partition_id.unique()[0]
    
    # Convert the arrays to list type
    cols = ['road_name', 'road_names', 'postal_code', 'postal_code_extended'] + [col for col in country_locality_pc_df.columns if 'array_' in col]
    for col in cols:
        country_locality_pc_df[col] = country_locality_pc_df[col].apply(lambda x: ast.literal_eval(x) if x != '' else [])
    
    country_locality_pc_df.postal_code = country_locality_pc_df.postal_code.apply(lambda x: x[0] if x else '')


    # MATCHING
    country_locality_pc_df['pc_similarity'] = country_locality_pc_df.apply(lambda x: process.extractOne(x.searched_query, x.postal_code_extended,
                                                                                                        scorer=token_set_ratio), axis=1)
    country_locality_pc_df['pc_best_match'] = country_locality_pc_df.pc_similarity.apply(lambda x: x[0] if x else '')
    country_locality_pc_df['pc_score'] = country_locality_pc_df.pc_similarity.apply(lambda x: x[1] if x else 0)
    country_locality_pc_df['postal_code_score'] = country_locality_pc_df.apply(lambda x: fuzz.token_set_ratio(x.searched_query, x.postal_code), axis=1)
    country_locality_pc_df['pc_similarity'] = country_locality_pc_df[['pc_score', 'postal_code_score']].max(axis=1)
    country_locality_pc_df = country_locality_pc_df.loc[country_locality_pc_df.groupby('searched_query').pc_similarity.idxmax()].reset_index(drop=True)
    country_locality_pc_df['address'] = np.where(country_locality_pc_df.postal_code_score > country_locality_pc_df.pc_score,
                                                 country_locality_pc_df.postal_code, 
                                                 country_locality_pc_df.pc_best_match)
    # PC match
    country_locality_pc_df['match'] = np.where(country_locality_pc_df.pc_similarity >= 80, 1, 0)

    # Get final columns with desired schema
    country_locality_pc_df['partition_id'] = partition_id
    country_locality_pc_df = country_locality_pc_df[cols_select]

    # Make sure to cast as DF
    country_locality_pc_df = pd.DataFrame(country_locality_pc_df)

    return country_locality_pc_df.fillna('').astype(str)


def ssf_matching(df:pd.DataFrame) -> pd.DataFrame:
    """
    Function used in the pyspark ApplyInPandas() function. Also the function applies the normalization, matching,
    and final values selction of the results.

    :param df: Input of the ApplyInPandas() that must be in pd.DataFrame format.
    :type df: pd.DataFrame
    :return: Output of the ApplyInPandas() that must be in pd.DataFrame format, otherwise empty dataframe with same columns is returned.
    :rtype: pd.DataFrame
    """

    cols_select = ['country', 'sample_id', 'searched_query', 'searched_query_type',
                   'lat', 'lon', 'version', 'address', 'match',
                   'array_admin_level_2_name', 'array_admin_level_7_name',
                   'array_admin_level_8_name', 'array_admin_level_9_name',
                   'localities_array', 'partition_id']

    
    # Prepare the DF
    country_locality_pc_stn_df = df.copy()
    partition_id = country_locality_pc_stn_df.partition_id.unique()[0]
    
    
    # Convert the arrays to list type
    cols = ['road_name', 'road_names', 'postal_code'] + [col for col in country_locality_pc_stn_df.columns if 'array_' in col]
    for col in cols:
        country_locality_pc_stn_df[col] = country_locality_pc_stn_df[col].apply(lambda x: ast.literal_eval(x) if x != '' else [])
    
    country_locality_pc_stn_df.postal_code = country_locality_pc_stn_df.postal_code.apply(lambda x: x[0][0] if x else '')


    # MATCHING
    # Merge both road name columns to one
    country_locality_pc_stn_df['road_name'] = country_locality_pc_stn_df.apply(lambda x: x.road_name + x.road_names, axis=1)
    
    # Convert road to unidecode
    country_locality_pc_stn_df['road_name_unidecode'] = country_locality_pc_stn_df.road_name.apply(lambda x: [unidecode.unidecode(j) for j in x] if x else [])
    
    # Compute similarities
    country_locality_pc_stn_df['road_similarity'] = country_locality_pc_stn_df.apply(lambda x: process.extractOne(x.libpostal_road, x.road_name), axis=1)
    country_locality_pc_stn_df['road_best_match'] = country_locality_pc_stn_df.road_similarity.apply(lambda x: x[0] if x else '')
    country_locality_pc_stn_df['road_score'] = country_locality_pc_stn_df.road_similarity.apply(lambda x: x[1] if x else '')
    
    # Compute similarity unidecode
    country_locality_pc_stn_df['road_similarity_unidecode'] = country_locality_pc_stn_df.apply(lambda x: process.extractOne(x.libpostal_road,
                                                                                                                            x.road_name_unidecode), axis=1)
    country_locality_pc_stn_df['road_unidecode_best_match'] = country_locality_pc_stn_df.road_similarity_unidecode.apply(lambda x: x[0] if x else '')
    country_locality_pc_stn_df['road_unidecode_score'] = country_locality_pc_stn_df.road_similarity_unidecode.apply(lambda x: x[1] if x else '')
    
    # Get max similarity and address
    country_locality_pc_stn_df['street_similarity'] = country_locality_pc_stn_df[['road_unidecode_score', 'road_score']].max(axis=1)
    country_locality_pc_stn_df['address'] = np.where(country_locality_pc_stn_df.road_unidecode_score > country_locality_pc_stn_df.road_score,
                                                     country_locality_pc_stn_df.road_unidecode_best_match, country_locality_pc_stn_df.road_best_match)
    
    # Compute matches
    country_locality_pc_stn_df = country_locality_pc_stn_df.loc[country_locality_pc_stn_df.groupby('searched_query').street_similarity.idxmax()].reset_index(drop=True)
    country_locality_pc_stn_df['match'] = np.where(country_locality_pc_stn_df.street_similarity >= 70, 1, 0)

    # Get final columns with desired schema
    country_locality_pc_stn_df['partition_id'] = partition_id
    country_locality_pc_stn_df = country_locality_pc_stn_df[cols_select]

    # Make sure to cast as DF
    country_locality_pc_stn_df = pd.DataFrame(country_locality_pc_stn_df)

    return country_locality_pc_stn_df.fillna('').astype(str)

def osm_hnr_matching(df:pd.DataFrame, country:str, libpostal_df:pd.DataFrame, stopwords_pattern:str='', source:str='clean') -> pd.DataFrame:
    """Performs matching on HNR

    :param df: pandas DataFrame containing addresses to search
    :type df: pd.DataFrame
    :param country: country to match
    :type country: str
    :param libpostal_df: DataFrame containing parsed searched queries
    :type libpostal_df: pd.DataFrame
    :param stopwords_pattern: regex pattern for the stopwords that musn't be considered
    :type stopwords_pattern: str
    :param source: 'clean' or 'raw'. String indicating which OSM to query (source or clean), defaults to 'clean'
    :type source: str, optional
    :return: DataFrame containing responses (positive or negative) for the addresses
    :rtype: pd.Dataframe
    """
    
    df_copy = df.copy()
    
    # Return empty dataframe if input is empty
    if df_copy.shape[0] == 0:
        return pd.DataFrame(columns=['searched_query', 'address', 'match', 'type', 'osm_id', 'tags',  'road_component',
                                     'postcode_similarity_best_score', 'city_component', 'state_component', 'coordinates', 'osm_lat', 'osm_lon', 'osm_query_distance'])
    
    # Get MNR schema
    country_schemas = find_osm_schema(country, latest=True, source=source)

    # Perform lookup
    country_lookup_df = osm_hnr_lookup(coordinates=df_copy.coordinates, schemas=country_schemas, source=source)

    # Merge to get original queries information
    country_hnr_df_lookup = country_lookup_df.merge(df_copy[['searched_query', 'lat', 'lon', 'searched_query_unidecode']],
                                                    how='right', 
                                                    left_on='index_searched_query', 
                                                    right_index=True).reset_index(drop=True)

    country_hnr_df_lookup = country_hnr_df_lookup.loc[~((country_hnr_df_lookup.road_name_way.isna()) 
                                                        & (country_hnr_df_lookup.road_name.isna()))].reset_index(drop=True)

    # Return empty dataframe if HNR is empty after filtering out null street names
    if country_hnr_df_lookup.shape[0] == 0:
        return pd.DataFrame(columns=['searched_query', 'address', 'match', 'type', 'osm_id', 'tags',  'road_component',
                                     'postcode_similarity_best_score', 'city_component', 'state_component', 'coordinates', 'osm_lat', 'osm_lon', 'osm_query_distance'])
    
    
    # Create street name column
    country_hnr_df_lookup['street_name'] = country_hnr_df_lookup.road_name_way.fillna(country_hnr_df_lookup.road_name)
    
    
    # Get only numeric components
    country_hnr_df_lookup['street_name_no_stopwords'] = country_hnr_df_lookup.street_name.str.replace(stopwords_pattern, '', case=False, regex=True)
    country_hnr_df_lookup['street_name_no_stopwords_unidecode'] = country_hnr_df_lookup.street_name.apply(lambda x: unidecode.unidecode(x))
    
    # Split into list and get smallest and biggest HSN in the range
    country_hnr_df_lookup['min_hsn_numeric'] = utils.get_numeric_house_number_column(country_hnr_df_lookup.min_hsn)
    country_hnr_df_lookup['min_hsn_numeric'] = country_hnr_df_lookup.min_hsn_numeric.apply(lambda x: min(x.split(' '))).astype(int)


    country_hnr_df_lookup[['max_hsn_numeric']] = utils.get_numeric_house_number_column(country_hnr_df_lookup.max_hsn)
    country_hnr_df_lookup['max_hsn_numeric'] = country_hnr_df_lookup.max_hsn_numeric.apply(lambda x: max(x.split(' '))).astype(int)


    # Recompute lowest and max depending on how the info was captured
    country_hnr_df_lookup['min_hsn_hnr'] = country_hnr_df_lookup[['min_hsn_numeric', 'max_hsn_numeric']].min(axis=1)
    country_hnr_df_lookup['max_hsn_hnr'] = country_hnr_df_lookup[['min_hsn_numeric', 'max_hsn_numeric']].max(axis=1)


    # Convert to odd number or even number depending on interpolation
    country_hnr_df_lookup['min_hsn_hnr'] = np.where(country_hnr_df_lookup.interpolation=='even', 
                                                    country_hnr_df_lookup.min_hsn_hnr // 2 * 2 ,
                                                   np.where(country_hnr_df_lookup.interpolation=='odd', country_hnr_df_lookup.min_hsn_hnr // 2 * 2 +1,
                                                            country_hnr_df_lookup.min_hsn_hnr))

    country_hnr_df_lookup['max_hsn_hnr'] = np.where(country_hnr_df_lookup.interpolation=='even', 
                                                    country_hnr_df_lookup.max_hsn_hnr // 2 * 2 ,
                                                   np.where(country_hnr_df_lookup.interpolation=='odd', country_hnr_df_lookup.max_hsn_hnr // 2 * 2 +1,
                                                            country_hnr_df_lookup.max_hsn_hnr))

    country_hnr_df_lookup['cadency'] = np.where(country_hnr_df_lookup.interpolation == 'all', 1, 2)



    country_hnr_df_lookup['hnr_array'] = country_hnr_df_lookup.apply(lambda x: list(np.arange(x.min_hsn_hnr,x.max_hsn_hnr+x.cadency,x.cadency)), 
                                                                     axis=1)
    country_hnr_df_lookup['hnr_array'] = country_hnr_df_lookup.hnr_array.apply(lambda x: [str(j) for j in x])

    
    # Join with libpostal
    country_hnr_df_lookup = country_hnr_df_lookup.merge(libpostal_df.drop(columns=['country', 'searched_query_unidecode']), on='searched_query')


    # Compute road similarity
    country_hnr_df_lookup['road_similarity_hnr'] = list(map(fuzz.token_set_ratio, country_hnr_df_lookup.libpostal_road_no_stopwords, 
                                                            country_hnr_df_lookup.street_name_no_stopwords))
    country_hnr_df_lookup['road_similarity_hnr_unidecode'] = list(map(fuzz.token_set_ratio, country_hnr_df_lookup.libpostal_road_no_stopwords, 
                                                            country_hnr_df_lookup.street_name_no_stopwords_unidecode))
    country_hnr_df_lookup['road_similarity_hnr'] = country_hnr_df_lookup[['road_similarity_hnr', 'road_similarity_hnr_unidecode']].max(axis=1)


    # Compute similarity for HSN
    country_hnr_df_lookup = country_hnr_df_lookup.loc[country_hnr_df_lookup.road_similarity_hnr >= 85].reset_index(drop=True)


    if country_hnr_df_lookup.shape[0] > 0:

        country_hnr_df_lookup['hnr_ratios'] = country_hnr_df_lookup.apply(lambda x: process.extractOne(x.libpostal_house_number, 
                                                                                                        x.hnr_array,
                                                                                                        scorer=token_set_ratio)[1], axis=1)
        country_hnr_df_lookup['hnr_regex_bool'] = country_hnr_df_lookup.apply(lambda x: max([bool(re.search('\\b'+j+'\\b', x.searched_query)) for j in x.hnr_array]), axis=1)

        # Compute match
        country_hnr_df_lookup['match'] = country_hnr_df_lookup.apply(lambda x: 1 
                                                                        if (x.road_similarity_hnr >= 85 and x.hnr_ratios >= 90) or x.hnr_regex_bool else 0, axis=1)


        country_hnr_df_lookup_final = country_hnr_df_lookup.loc[country_hnr_df_lookup.groupby('searched_query').match.idxmax()].reset_index(drop=True)
        
        country_hnr_df_lookup_final['postcode_similarity_best_score'] = country_hnr_df_lookup_final.postal_code.fillna('').apply(lambda x: x[0] if x != '' else '')
        country_hnr_df_lookup_final['addr_housenumber'] = np.where(country_hnr_df_lookup_final.match==1, country_hnr_df_lookup_final.libpostal_house_number, pd.NA)
        country_hnr_df_lookup_final['address'] = (country_hnr_df_lookup_final.libpostal_house_number + ' ' + 
                                                  country_hnr_df_lookup_final.street_name + ' ' + 
                                                  country_hnr_df_lookup_final.postcode_similarity_best_score + ' ' +
                                                  country_hnr_df_lookup_final.city_name.fillna('') + ' ' +
                                                  country_hnr_df_lookup_final.state_name.fillna('')
                                                 )
        country_hnr_df_lookup_final['type'] = 'Address Range'


        country_hnr_df_lookup_final['provider_coordinates'] = gpd.GeoSeries.from_wkt(country_hnr_df_lookup_final.way).centroid
        country_hnr_df_lookup_final['osm_lat'] = country_hnr_df_lookup_final.provider_coordinates.apply(lambda p: p.y)
        country_hnr_df_lookup_final['osm_lon'] = country_hnr_df_lookup_final.provider_coordinates.apply(lambda p: p.x)

        country_hnr_df_lookup_final['osm_query_distance'] = country_hnr_df_lookup_final.apply(lambda p: haversine_distance(p.osm_lat,
                                                                                                                               p.osm_lon,
                                                                                                                               p.lat, p.lon), axis=1)
        
        # Rename columns to allow integration with APTs
        country_hnr_df_lookup_final = country_hnr_df_lookup_final.rename(columns={'street_name': 'road_component', 
                                                                                  'city_name': 'city_component', 
                                                                                  'state_name': 'state_component', 
                                                                                  'tags_network': 'tags'})
        
        country_hnr_df_lookup_final['osm_id'] = country_hnr_df_lookup_final.osm_id.astype(int).astype(str)
        
        
        return country_hnr_df_lookup_final
    else:
        return pd.DataFrame(columns=['searched_query', 'address', 'match', 'type', 'osm_id', 'tags',  'road_component',
                                     'postcode_similarity_best_score', 'city_component', 'state_component', 'coordinates', 'osm_lat', 'osm_lon', 'osm_query_distance'])



def lookup_osm_components(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, source:str='clean') -> gpd.GeoDataFrame:
    """Find the L2 components for OSM

    :param coordinates: coordinates of APTs to query
    :type coordinates: gpd.GeoSeries
    :param schemas: dataframe containing the schemas to use
    :type schemas: pd.DataFrame
    :param source: 'clean' or 'raw'. String indicating which OSM to query (source or clean), defaults to 'clean'
    :type source: str, optional
    :return: localities, postal code and street near the points
    :rtype: gpd.GeoDataFrame
    """
    
    # Create query for addresses to reverse lookup
    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                         from """ + utils.convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    
    
    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Get the db to query
    if source=='clean':
        db = 'osm-clean'
    elif source=='raw':
        db = 'osm-source'
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', db)

        query_buffers = """  
        with sample as ({query_coordinates})
        
        , tags as (
        select distinct skeys(tags) keys
        from {schema}.planet_osm_polygon pop 
        where admin_level  in ('4', '8')
        )

        , name_tags as (
        select * 
        from tags
        where (keys like '%name:%' or keys like '%alt%name') and keys not like '%pronunciation%'
        )
        
        , city_state_tags as (
        select distinct skeys(tags) keys
        from {schema}.planet_osm_point 
        where tags::text like '%addr:city%' or tags::text like '%addr:state%'
        )

        , locality_tags as (
        select * 
        from city_state_tags
        where (keys like '%addr:city%' or keys like '%addr:state%' or keys like '%addr:postcode%') and keys not like '%pronunciation%'
        )
        
        , buffers as (
        select 
                sample.index_searched_query
            ,   sample.coordinates
            ,   ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), 10), 4326) buffer
        from sample 
        )
        
        , components as (
            select 
                sample.index_searched_query
            ,   sample.coordinates
            ,   '{date}' as date
            ,   '{version}' as version
            ,   sample.buffer
            ,   postcode.postcode as postal_code
            ,	locality.admin_level_2_name
            ,	locality.array_admin_level_2_name
            ,	locality.admin_level_4_name
            ,	locality.array_admin_level_4_name
            ,	locality.admin_level_5_name
            ,	locality.array_admin_level_5_name
            ,	locality.admin_level_6_name
            ,	locality.array_admin_level_6_name
            ,	locality.admin_level_7_name
            ,	locality.array_admin_level_7_name
            ,	locality.admin_level_8_name
            ,	locality.array_admin_level_8_name
            ,	locality.admin_level_9_name
            ,	locality.array_admin_level_9_name
            ,	locality.admin_level_10_name
            ,	locality.array_admin_level_10_name
            ,   array_remove(array_agg(road.road), null) as road_name
            ,	array_remove(name_tags_array, null) as road_names
            ,	array_remove(array_agg(distinct loc_node.localities), null) as localities_array
            ,	array_remove(array_agg(distinct loc_node.postcode), null) as postal_code_extended
            from buffers as sample


            left join lateral (
                            SELECT name as road, tags->array((select keys from name_tags)) as name_tags_array
                            FROM {schema}.planet_osm_line road
                            where name is not null
                            and highway  in ('motorway','motorway_link','trunk','trunk_link','primary','primary_link','secondary','secondary_link','tertiary','tertiary_link','unclassified','residential','service','living_street','road','steps', 'footway', 'path', 'pedestrian', 'bridleway', 'cycleway', 'track')
                            ORDER BY road.way <-> sample.coordinates

                            LIMIT 4
                            ) AS road
            on true


            left outer join(
                        
                select index_searched_query, array_agg(distinct postcode) as postcode 
                from
                        (Select
                        sample.index_searched_query,
                        way,
                    --   array_agg( array_remove(ARRAY[tags->'postal_code',tags->'addr:postal_code',tags->'postcode', tags->'addr:postcode'], null) ) postcode
                        unnest(array_remove(tags->array['postal_code', 'addr:postal_code', 'postcode', 'addr:postcode'], null)) as postcode
                        From {schema}.planet_osm_polygon polygon

                        join sample on ST_Intersects(sample.coordinates, polygon.way)

                        Where (tags?|ARRAY['postal_code','addr:postal_code','postcode','addr:postcode'] AND boundary = 'administrative')
                        OR boundary = 'postal_code'

                        ) a
                
                where postcode is not null
                group by index_searched_query    
                    
                            ) AS postcode
            on postcode.index_searched_query = sample.index_searched_query


            left outer join (

            select 
                index_searched_query
            ,	max(case when admin_level='2' then array[name, cntry_code] else null end) as admin_level_2_name
        	,	max(case when admin_level='2' then array_remove(tags->array((select keys from name_tags)), null) else null end ) as array_admin_level_2_name
            ,	max(case when admin_level='4' then name else null end) as admin_level_4_name
            ,	max(case when admin_level='4' then array_remove(tags->array((select keys from name_tags)), null) else null end ) as array_admin_level_4_name
            ,	max(case when admin_level='5' then name else null end) as admin_level_5_name
            ,	max(case when admin_level='5' then array_remove(tags->array((select keys from name_tags)), null) else null end ) as array_admin_level_5_name
            ,	max(case when admin_level='6' then name else null end) as admin_level_6_name
            ,	max(case when admin_level='6' then array_remove(tags->array((select keys from name_tags)), null) else null end ) as array_admin_level_6_name
            ,	max(case when admin_level='7' then name else null end) as admin_level_7_name
            ,	max(case when admin_level='7' then array_remove(tags->array((select keys from name_tags)), null) else null end ) as array_admin_level_7_name
            ,	max(case when admin_level='8' then name else null end) as admin_level_8_name
            ,	max(case when admin_level='8' then array_remove(tags->array((select keys from name_tags)), null) else null end ) as array_admin_level_8_name
            ,	max(case when admin_level='9' then name else null end) as admin_level_9_name
            ,	max(case when admin_level='9' then array_remove(tags->array((select keys from name_tags)), null) else null end ) as array_admin_level_9_name
            ,	max(case when admin_level='10' then name else null end) as admin_level_10_name
            ,	max(case when admin_level='10' then array_remove(tags->array((select keys from name_tags)), null) else null end ) as array_admin_level_10_name
            from {schema}.planet_osm_polygon pop 
            
            join sample on ST_Intersects(pop.way, sample.coordinates)
            
            where (admin_level >= '4' or admin_level='2')
            and boundary in ('administrative')
            
            group by index_searched_query
                            ) locality 
            on sample.index_searched_query = locality.index_searched_query
            
            
            left outer join (
                    select 
                        buffers.index_searched_query
                    ,	unnest(tags->array((select keys from locality_tags where keys like '%city%' or keys like '%state%'))) as  localities
                    ,   unnest(tags->array((select keys from locality_tags where keys like '%postcode%'))) as postcode
                    from {schema}.planet_osm_point points 
                    
                    join buffers on ST_Intersects(buffers.buffer, points.way)
            ) loc_node 
            on loc_node.index_searched_query = sample.index_searched_query
    
    
        group by 
            sample.index_searched_query
            ,   sample.coordinates
            ,   sample.buffer
            ,   postcode.postcode
            ,	locality.admin_level_2_name
            ,	locality.array_admin_level_2_name
            ,	locality.admin_level_4_name
            ,	locality.array_admin_level_4_name
            ,	locality.admin_level_5_name
            ,	locality.array_admin_level_5_name
            ,	locality.admin_level_6_name
            ,	locality.array_admin_level_6_name
            ,	locality.admin_level_7_name
            ,	locality.array_admin_level_7_name
            ,	locality.admin_level_8_name
            ,	locality.array_admin_level_8_name
            ,	locality.admin_level_9_name
            ,	locality.array_admin_level_9_name
            ,	locality.admin_level_10_name
            ,	locality.array_admin_level_10_name
            ,	array_remove(name_tags_array, null)
        )


        select * 
        from components
        """.format(query_coordinates=query_coordinates,
                   date=row.date,   
                   schema=row.nspname,
                   version=row.date)
        
        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_buffers, conn, geom_col='coordinates')


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)


    return gpd.GeoDataFrame(lookup_df)
        


def appPandas_osm_recursive_calls(df:pd.DataFrame, libpostal_df:pd.DataFrame, 
                              radius_list:typing.List[float], stopwords_dict:dict, source:str='clean') -> pd.DataFrame:
    """Makes recursive calls to Openmap's PBF to get matching APTs

    :param df: DataFrame containing sample addresses with reference coordinates in column 'coordinates'
    :type df: pd.DataFrame
    :param country:  country in ISO2 or ISO3 format
    :type country: str
    :param libpostal_df: libpostal containing the address components of the sample addresses in 'df'. Used for matching
    :type libpostal_df: pd.DataFrame
    :param radius_list: list of raidus to look for APTs in the Openmap's PBF
    :type radius_list: typing.List[float]
    :param stopwords_dict: dictionary containing common stopwords for each country
    :type stopwords_dict: dict
    :param source: which database to query ('source' or 'raw')
    :type source: str
    :return: DataFrame containing the matches for 
    :rtype: pd.DataFrame
    """
    
    # These will be the output columns, no matter what
    cols_select = ['country','searched_query', 'partition_id', 'lat','lon','searched_query_unidecode', 'release_date', 'product_version',
                    'type', 'osm_id', 'tags', 'address', 'osm_lat', 'osm_lon', 'match', 'osm_query_distance', 'mean_similarity',
                    'addr_housenumber', 'road_component','city_component', 'postcode_similarity_best_score', 'state_component', 'locality_similarity', 'road_similarity', 'postcode_similarity', 
                    'hsn_similarity','road_names', 'city_names', 'state_names']
    
    
    # We try to make the geospatial call, if not, we return an empty DataFrame with the same columns
    try:
        # Prepare the DF
        df_copy = df.copy()
        libpostal_df_copy = libpostal_df.copy()
        
        
        df_copy['coordinates'] = gpd.GeoSeries.from_wkt(df_copy.coordinates.astype(str))
        df_copy[['lat', 'lon']] = df_copy[['lat', 'lon']].astype(float)
        df_copy = gpd.GeoDataFrame(df_copy, geometry='coordinates')
        
        
        # Get inputs
        country = df_copy.country.unique()[0]
        stopwords_pattern = stopwords_dict.get(country, '')
        partition_id = df_copy.partition_id.unique()[0]
        
        
        libpostal_columns = ['searched_query_unidecode', 'libpostal_road', 'libpostal_city', 'libpostal_state']
        for col in libpostal_columns:
            col_create = col + '_no_stopwords'
            libpostal_df_copy[col_create] = libpostal_df_copy[col].str.replace(stopwords_pattern, '', case=False, regex=True)
        

        # Compute first result
        radius_result = osm_call_radius(df_copy, country, libpostal_df_copy, radius_list[0], 0, stopwords_pattern, source)
        apt_match_df = radius_result.loc[radius_result.match==1].reset_index(drop=True)
        missing_apts_df = df_copy.loc[~df_copy.searched_query.isin(apt_match_df.searched_query)].reset_index(drop=True)
        
        
        # Compute remaining results for other radius
        if len(radius_list) > 1:
            for idx, radius in enumerate(radius_list[1:]):
                if missing_apts_df.shape[0] > 0:
                    radius_result = osm_call_radius(missing_apts_df, country, libpostal_df_copy, radius,
                                                        radius_list[idx]-5, stopwords_pattern, source)
                    matching_found = radius_result.loc[radius_result.match==1].reset_index(drop=True)

                        
                    # Concatenate to existing DF
                    apt_match_df = pd.concat([apt_match_df, matching_found], ignore_index=True)
                    missing_apts_df = df_copy.loc[~df_copy.searched_query.isin(apt_match_df.searched_query)].reset_index(drop=True)
                
    
        # Add latest results but missing
        radius_result['match'] = radius_result.match.fillna(0)
        matching_not_found = radius_result.loc[radius_result.match==0].reset_index(drop=True)
        apt_match_df = pd.concat([apt_match_df, matching_not_found], ignore_index=True)
        
        
        # Merge back to original dataframe and fill NA with 0s
        apt_match_df = df_copy.merge(apt_match_df.drop(columns=['lat', 'lon',  'coordinates', 'searched_query_unidecode']),
                                    on=['searched_query', 'country'],
                                    how='left')
        apt_match_df['match'] = apt_match_df.match.fillna(0)
        
        # One last run to avoid issues with SQL
        partial_df = apt_match_df.loc[apt_match_df.match==1].reset_index(drop=True)
        missing_queries = apt_match_df.loc[(apt_match_df.match==0) | (apt_match_df.match.isna())].searched_query

        # Checked dimensionality one last time
        if missing_queries.shape[0] == 0:
            apt_match_df['partition_id'] = partition_id
            return apt_match_df[cols_select].fillna('').astype(str)


        country_sample_missing_gdf = df_copy.loc[df_copy.searched_query.isin(missing_queries)].reset_index(drop=True)
        missing_results_df = osm_call_radius(country_sample_missing_gdf,
                                                country=country,
                                                libpostal_df=libpostal_df_copy, 
                                                radius=250,
                                                inner_radius=0,
                                                stopwords_pattern=stopwords_pattern, 
                                                source=source)

        apt_match_final_df = pd.concat([partial_df, missing_results_df], ignore_index=True)
        apt_match_final_df['match'] = apt_match_final_df.match.fillna(0)

        
        # Now match with HNR
        missing_queries = apt_match_final_df.loc[(apt_match_final_df.match==0) | (apt_match_final_df.match.isna())].searched_query
        country_sample_missing_gdf = df_copy.loc[df_copy.searched_query.isin(missing_queries)].reset_index(drop=True)
        hnr_match_df = osm_hnr_matching(df=country_sample_missing_gdf, country=country, libpostal_df=libpostal_df_copy, stopwords_pattern=stopwords_pattern, source=source)

        # Merge all results
        countries_apt_final_matching_df = df_copy.merge(apt_match_final_df.drop(columns=['lat', 'lon', 'country', 'coordinates', 'searched_query_unidecode']),
                                                        on='searched_query',
                                                        how='left')
        countries_apt_final_matching_df['match'] = countries_apt_final_matching_df.match.fillna(0)

        # Get HNR matches
        countries_apt_final_matching_df = countries_apt_final_matching_df.merge(hnr_match_df[['searched_query', 'address', 'match', 'type', 'osm_id', 'tags',  'road_component',   
                                                                                              'postcode_similarity_best_score', 'city_component', 'state_component', 'coordinates', 
                                                                                              'osm_lat', 'osm_lon', 'osm_query_distance']],
                                                                                on='searched_query',
                                                                                how='left',
                                                                                suffixes=('', '_hnr'))

        countries_apt_final_matching_df['type'] = np.where(countries_apt_final_matching_df.match_hnr > countries_apt_final_matching_df.match, 'Address Range', 
                                                            countries_apt_final_matching_df['type'])

        # Complement with HNR matches
        cols_imputation = ['address', 'osm_lat', 'osm_lon', 'osm_query_distance', 'road_component', 'postcode_similarity_best_score', 'city_component', 
                           'state_component', 'match']
        
        for col in cols_imputation:
            countries_apt_final_matching_df[col] = np.where(countries_apt_final_matching_df.match_hnr > countries_apt_final_matching_df.match, 
                                                            countries_apt_final_matching_df[col+'_hnr'], countries_apt_final_matching_df[col])

        # Make sure to cast as DF
        countries_apt_final_matching_df['partition_id'] = partition_id
        countries_apt_final_matching_df = pd.DataFrame(countries_apt_final_matching_df)

        return countries_apt_final_matching_df[cols_select].fillna('').astype(str)


    except Exception as e:
        print(e)
        return pd.DataFrame(columns=cols_select, dtype=str)
        
        
def osm_poi_lookup(df:gpd.GeoDataFrame, 
                  mapping_df: pd.DataFrame, 
                  radius: int or float = 500,
                  source: str = 'clean') -> gpd.GeoDataFrame:
    """Finds the POIs of similar category for sample POIs

    :param df: DataFrame containing at least 'coordinates' and 'category_id_tt' columns
    :type df: gpd.GeoDataFrame
    :param mapping_df: mapping category for similar POIs, given a category
    :type mapping_df: pd.DataFrame
    :param radius: radius to lookup, defaults to 500
    :type radius: int or float, optional
    :param source: which database to query ('source' or 'raw')
    :type source: str
    :return: DataFrame containing only the relevant POIs similar to the category in question
    :rtype: gpd.GeoDataFrame
    """
    
    df_copy = df.copy()
    
    
    # Get the db to query
    if source=='clean':
        db = 'osm-clean'
    elif source=='raw':
        db = 'osm-source'
    
    
    # Find country schema
    country = df_copy.country.unique()[0]
    schema = find_osm_schema(country, source=source)
    
    
    # Initiate mapping dataframe if not initialized
    mapping_df['category_code'] = mapping_df.category_code.astype(str)
    
    
    # Create mapping SQL query
    country_mapping = mapping_df.loc[mapping_df.category_code.isin(df_copy.category_id_tt)].reset_index(drop=True)
    query_country = '\n, '.join((country_mapping.case_when_column + ' ' + country_mapping.then_end).tolist())
    condition_category_country = ' + '.join(('category_' + country_mapping.category_id.astype(str)).tolist()) + ' > 0'
    unnest_names = f'array{str(country_mapping.category_id.astype(str).tolist())}'
    unnest_values = 'array'+str(('category_' + country_mapping.category_id.astype(str)).tolist()).replace("'", "")


    # Create base query for spatial lookups
    query_coordinates = """select index_searched_query,  st_geomfromtext (coordinates, 4326)  coordinates, category_id
                    from """ + utils.convert_poi_to_query(df_copy) + " as t (index_searched_query, coordinates, category_id)"
                    
    
        # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schema.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', db)
    
        # Create query
        query_complete = """ 
        with sample as ({query_coordinates})
        
        , tags as (
        select distinct skeys(tags) keys
        from {schema}.planet_osm_point pop  
        where name is not null or tags::text like '%name:%'
        )

        , name_tags as (
        select * 
        from tags
        where (keys like '%name:%' or keys like '%alt%name' or keys like '%brand%') and keys not like '%pronunciation%' and keys not like '%wiki%'
        )

        , buffers as (
        select  
            sample.index_searched_query
            , sample.coordinates
            , sample.category_id
            , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
        from sample
        )  

        , pois as (select 
            *, 
            unnest({unnest_names}) as category_poi,
            unnest({unnest_values}) as value
        from
        (
        select 
            buffers.index_searched_query
        ,   buffers.category_id
        ,   brand
        ,   name
        ,   osm_id
        ,   tags
        ,   way 
        ,  'point' as type
        ,  {query}

        from {schema}.planet_osm_point point
        join buffers on ST_Intersects(point.way, buffers.buffer)

        union all

        select 
            buffers.index_searched_query
        ,   buffers.category_id
        ,   brand
        ,   name
        ,   osm_id
        ,   tags
        ,   ST_Centroid(way) as way
        ,   'polygon' as type
        , {query}

        from {schema}.planet_osm_polygon poly
        join buffers on ST_Intersects(poly.way, buffers.buffer)
        ) a

        where {condition_category}
        and (name is not null or tags::text like '%name:%')
        )

        select  
            index_searched_query
        ,   category_id 
        ,   name as name_response
        ,   brand as brand_response
        ,   '{date}' as release_date
        ,   '{version}' as product_version
        ,   osm_id 
        ,   tags
        ,   way
        ,   type
        ,   category_poi
        ,   array_remove(tags->array((select keys from name_tags where keys like '%name%')), null) as name_tags
        ,   array_remove(tags->array((select keys from name_tags where keys like '%brand%')), null) as brand_tags
        from pois
        where value=1""".format(query=query_country, schema=row.nspname, condition_category=condition_category_country,
                                unnest_names=unnest_names, unnest_values=unnest_values, query_coordinates=query_coordinates, 
                                radius=radius, date=row.date, version=row.date)
        
        
        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_complete, conn, geom_col='way')


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()


    return gpd.GeoDataFrame(lookup_df)
        
        
def appPandas_osm_poi_lookup(df:pd.DataFrame,  sampling_configuration_df:pd.DataFrame, poi_osm_mapping_merged:pd.DataFrame, source:str = 'clean') -> pd.DataFrame:
    """Finds the POIs of similar category for sample POIs

    :param df: DataFrame containing at least 'coordinates' and 'category_id_tt' columns
    :type df: gpd.GeoDataFrame
    :param sampling_configuration_df: DataFrame containing relevant data for each category, such as radius of call
    :type sampling_configuration_df: pd.DataFrame
    :param poi_osm_mapping_merged: DataFrame containing the mapping between TT categories and OSM categories
    :type poi_osm_mapping_merged: pd.DataFrame
    :param source: which database to query ('source' or 'raw')
    :type source: str
    :return: DataFrame containing only the relevant POIs similar to the category in question
    :rtype: gpd.GeoDataFrame
    """
    
    df_copy = df.copy()
    df_copy['coordinates'] = gpd.GeoSeries.from_wkt(df_copy.wkt)
    df_copy = gpd.GeoDataFrame(df_copy, geometry='coordinates')
    
    
    # Get the db to query
    if source=='clean':
        db = 'osm-clean'
    elif source=='raw':
        db = 'osm-source'
    
    
    # Find country schema
    country = df_copy.country.unique()[0]
    schema = find_osm_schema(country, source=source)
    
    
    # Initiate mapping dataframe if not initialized
    category = df_copy.category_id_tt.unique()[0]
    radius = sampling_configuration_df.loc[sampling_configuration_df.category_id_tt==category].radius_m.iloc[0]
    mapping_df = poi_osm_mapping_merged.loc[poi_osm_mapping_merged.category_code==category].reset_index(drop=True)
    
    
    # Create mapping SQL query
    country_mapping = mapping_df.loc[mapping_df.category_code.isin(df_copy.category_id_tt)].reset_index(drop=True)
    query_country = '\n, '.join((country_mapping.case_when_column + ' ' + country_mapping.then_end).tolist())
    condition_category_country = ' + '.join(('category_' + country_mapping.category_id.astype(str)).tolist()) + ' > 0'
    unnest_names = f'array{str(country_mapping.category_id.astype(str).tolist())}'
    unnest_values = 'array'+str(('category_' + country_mapping.category_id.astype(str)).tolist()).replace("'", "")


    # Create base query for spatial lookups
    query_coordinates = """select index_searched_query,  st_geomfromtext (coordinates, 4326)  coordinates, category_id
                    from """ + utils.convert_poi_to_query(df_copy) + " as t (index_searched_query, coordinates, category_id)"
                    
    
    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schema.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', db)
    
        # Create query
        query_complete = """ 
        with sample as ({query_coordinates})
        
        , tags as (
        select distinct skeys(tags) keys
        from {schema}.planet_osm_point pop  
        where name is not null or tags::text like '%name:%'
        )

        , name_tags as (
        select * 
        from tags
        where (keys like '%name:%' or keys like '%alt%name' or keys like '%brand%') and keys not like '%pronunciation%' and keys not like '%wiki%'
        )

        , buffers as (
        select  
            sample.index_searched_query
            , sample.coordinates
            , sample.category_id
            , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
        from sample
        )  

        , pois as (select 
            *, 
            unnest({unnest_names}) as category_poi,
            unnest({unnest_values}) as value
        from
        (
        select 
            buffers.index_searched_query
        ,   buffers.category_id
        ,   brand
        ,   name
        ,   osm_id
        ,   tags
        ,   way 
        ,  'point' as type
        ,  {query}

        from {schema}.planet_osm_point point
        join buffers on ST_Intersects(point.way, buffers.buffer)

        union all

        select 
            buffers.index_searched_query
        ,   buffers.category_id
        ,   brand
        ,   name
        ,   osm_id
        ,   tags
        ,   ST_Centroid(way) as way
        ,   'polygon' as type
        , {query}

        from {schema}.planet_osm_polygon poly
        join buffers on ST_Intersects(poly.way, buffers.buffer)
        ) a

        where {condition_category}
        and (name is not null or tags::text like '%name:%')
        )

        select  
            index_searched_query
        ,   category_id 
        ,   name as name_response
        ,   brand as brand_response
        ,   '{date}' as release_date
        ,   '{version}' as product_version
        ,   osm_id 
        ,   tags
        ,   way
        ,   st_x(way) as provider_lon
        ,   st_y(way) as provider_lat
        ,   type
        ,   category_poi
        ,   array_remove(tags->array((select keys from name_tags where keys like '%name%')), null) as name_tags
        ,   array_remove(tags->array((select keys from name_tags where keys like '%brand%')), null) as brand_tags
        from pois
        where value=1""".format(query=query_country, schema=row.nspname, condition_category=condition_category_country,
                                unnest_names=unnest_names, unnest_values=unnest_values, query_coordinates=query_coordinates, 
                                radius=radius, date=row.date, version=row.date)
        
        
        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_complete, conn, geom_col='way')


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
        
        
    lookup_merged_df = pd.DataFrame(lookup_df).merge(df_copy, how='right', left_on='index_searched_query', right_index=True)
    lookup_merged_df = lookup_merged_df.astype(str)
    
    # Fill some NAs
    lookup_merged_df['product_version'] = np.where(lookup_merged_df.product_version=='nan', pd.NA, lookup_merged_df.product_version)
    lookup_merged_df['product_version'] = lookup_merged_df.product_version.fillna(str(row.date))
    lookup_merged_df = lookup_merged_df.replace({'nan':''})
    
    
    return lookup_merged_df
  
  
if __name__=='__main__':
    # Create test dataframe
    test_addresses = [('11-97 DE ENTREE AMSTERDAM 1101 HE NLD', 52.31177019833552, 4.939634271503648),
                    ('Aalsterweg 303, 5644 RL Eindhoven, NL', 51.41176179168882, 5.482757611072691),
                    ('Ammunitiehaven 343 2511 XM s Gravenhage NL', 52.07742315143409, 4.3212179573462075),
                    ('Baarsweg 148, 3192 VB, Hoogvliet Rotterdam, Ne...', 51.856975720153564, 4.350903401715045),
                    ('Baas Gansendonckstraat 3, 1061CZ Amsterdam, NL', 52.37733757641722, 4.840407597295104)
                    ]


    test_df = pd.DataFrame(test_addresses, columns=['searched_query', 'lat', 'lon'])
    test_df['coordinates'] = test_df.apply(lambda x: shapely.geometry.Point(x.lon, x.lat), axis=1)
    test_gdf = gpd.GeoDataFrame(test_df, geometry='coordinates')


    # Country schema
    nld_openmap_schema = find_osm_schema('nld')
    nld_openmap_result = osm_lookup(test_gdf.coordinates, nld_openmap_schema)
    nld_openmap_result = parse_osm_tags(nld_openmap_result)
    
    
    # Test POIS 
    test_pois_addresses = [('Post Office Agency Communal', 16.204411, -61.651168999999996),
                        ('CREDIT MUTUEL LES ABYMES',	16.275899799999998,	-61.510723299999995),
                        ('Pharmacie Combé',	16.0402232,	-61.566468799999996),
                        ('Jarry Fitness Club',	16.2413296,	-61.569329599999996)]
    
    test_pois_df = pd.DataFrame(test_pois_addresses, columns=['searched_query', 'lat', 'lon'])
    test_pois_df['coordinates'] = test_pois_df.apply(lambda x: shapely.geometry.Point(x.lon, x.lat), axis=1)
    test_pois_gdf = gpd.GeoDataFrame(test_pois_df, geometry='coordinates')
    
    schema = find_osm_schema('GLP')

    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                            from """ + convert_coordinates_to_query(test_pois_gdf.coordinates) + " as t (index_searched_query, coordinates)"

    result = poi_osm_lookup(test_pois_gdf.coordinates, schema, 1000)